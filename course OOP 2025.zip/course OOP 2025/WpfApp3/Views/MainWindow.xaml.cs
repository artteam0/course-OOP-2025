﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp3.Data;
using WpfApp3.ViewModel;
using WpfApp3.ViewModels;
using WpfApp3.Services;

namespace WpfApp3.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindow_MVVM();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string from = ComboFrom.Text;
            string to = ComboTo.Text;
            DateTime date = DatePickerMain.SelectedDate ?? DateTime.Today;
            string time = TimePicker.Text;
            if (string.IsNullOrWhiteSpace(from))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(to))
            {
                return;
            }

            if (from == to)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(time))
            {
                return;
            }

            var filterWindow = new FilterRoute(from, to, date, time);
            filterWindow.Show();
            Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()?.Close();
        }

        //private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        //{
        //    if (this.WindowState == WindowState.Normal)
        //    {
        //        App.WindowSizeService.Width = this.Width;
        //        App.WindowSizeService.Height = this.Height;
        //        App.WindowSizeService.Left = this.Left;
        //        App.WindowSizeService.Top = this.Top;
        //    }

        //    App.WindowSizeService.State = this.WindowState;
        //}

        //private void Window_LocationChanged(object sender, EventArgs e)
        //{
        //    if (this.WindowState == WindowState.Normal)
        //    {
        //        App.WindowSizeService.Left = this.Left;
        //        App.WindowSizeService.Top = this.Top;
        //    }
        //}
    }
}
