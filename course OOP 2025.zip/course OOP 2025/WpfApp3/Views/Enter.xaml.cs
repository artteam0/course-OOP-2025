﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp3.ViewModel;
using WpfApp3.ViewModels;
using WpfApp3.Data;
using WpfApp3.Views;

namespace WpfApp3.Views
{
    public partial class Enter : Window
    {
        public Enter()
        {
            InitializeComponent();
            DataContext = new Enter_MVVM();
        }
        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            var passwordBox = (PasswordBox)sender;
            var viewModel = (Enter_MVVM)this.DataContext;

            viewModel.Password = passwordBox.Password;
            if (PasswordPlaceholder != null)
            {
                PasswordPlaceholder.Visibility = string.IsNullOrEmpty(PasswordInput.Password)
                    ? Visibility.Visible
                    : Visibility.Collapsed;
            }
        }
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                EnterButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            }
        }
    }
}
