﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.ViewModel;
using WpfApp3.ViewModels;
using WpfApp3.Views;

namespace WpfApp3.Views
{
    public partial class FilterRoute : Window
    {
        private PurchaseControl _purchaseControl;
        private PurchaseControl_MVVM _purchaseVM;

        private readonly FilterRoute_MVVM _viewModel;

        public FilterRoute()
        {
            InitializeComponent();

            _viewModel = new FilterRoute_MVVM();
            DataContext = _viewModel;

            _purchaseVM = new PurchaseControl_MVVM();
            _purchaseVM.OnConfirmed += PurchaseConfirmed;
            _purchaseVM.OnCancelled += PurchaseCancelled;

            _purchaseControl = new PurchaseControl { DataContext = _purchaseVM };

            PurchaseHost.Content = _purchaseControl;

            _viewModel.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(_viewModel.IsPurchaseVisible))
                {
                    PurchaseHost.Visibility = _viewModel.IsPurchaseVisible ? Visibility.Visible : Visibility.Collapsed;

                    if (_viewModel.IsPurchaseVisible)
                    {
                        _purchaseVM.SelectedRoute = _viewModel.RouteBeingPurchased;
                        _purchaseVM.CurrentUser = UserSession.CurrentUser;

                        _purchaseVM.SelectedSeatCount = 1;
                        _purchaseVM.SelectedPaymentMethod = _purchaseVM.PaymentMethods.FirstOrDefault();
                    }
                }
            };
        }

        public FilterRoute(string from, string to, DateTime date, string time) : this()
        {
            _viewModel.SearchFromMain(from, to, date, time);
        }

        private void PurchaseConfirmed(int seats, string paymentMethod)
        {
            _viewModel.IsPurchaseVisible = false;

            var route = _viewModel.RouteBeingPurchased;

            SelectedRouteService.AddRoute(route);

            MessageBox.Show($"Куплено мест: {seats}\nСпособ оплаты: {paymentMethod}\nМаршрут добавлен в поездки");
        }

        private void PurchaseCancelled()
        {
            _viewModel.IsPurchaseVisible = false;
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void OpenProfileButton_Click(object sender, RoutedEventArgs e)
        {
            if (!UserSession.IsLoggedIn)
            {
                MessageBox.Show("Для доступа к профилю необходимо войти в систему.", "Аутентификация не пройдена", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (UserSession.CurrentUser != null && (UserSession.ActiveRole == "User" || UserSession.ActiveRole == "Admin"))
            {
                Profile profileWindow = new Profile();
                profileWindow.Owner = this;
                profileWindow.ShowDialog();
            }
            else if (UserSession.CurrentDriver != null && UserSession.ActiveRole == "Driver")
            {
                MessageBox.Show("Данный раздел профиля предназначен для пользователей, а не для водителей.", "Доступ ограничен", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Не удалось определить тип вашей учетной записи. Пожалуйста, перезайдите в систему.", "Ошибка сессии", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
