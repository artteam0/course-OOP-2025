﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp3.Data;
using WpfApp3.ViewModel;
using WpfApp3.ViewModels;

namespace WpfApp3.Views
{
    public partial class AdminPanelWindow : Window
    {
        public AdminPanelWindow()
        {
            InitializeComponent();
            DataContext = new AdminPanelWindow_MVVM();
        }
        private void DriverPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is AdminPanelWindow_MVVM vm)
            {
                vm.Password = ((PasswordBox)sender).Password;
            }
            var passwordBox = (PasswordBox)sender;
            var viewModel = (AdminPanelWindow_MVVM)this.DataContext;

            viewModel.Password = passwordBox.Password;
            if (PasswordPlaceholder != null)
            {
                PasswordPlaceholder.Visibility = string.IsNullOrEmpty(DriverPasswordBox.Password)
                    ? Visibility.Visible
                    : Visibility.Collapsed;
            }
        }
    }
}
