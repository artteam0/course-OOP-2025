﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WpfApp3.Data;

namespace WpfApp3.Views
{
    public partial class Profile : Window, INotifyPropertyChanged
    {
        private int _currentLoggedInUserId;
        private string _currentLoggedInUserEmail;
        private string _currentLoggedInUserPasswordHash;

        private string _statusMessageKey;
        public string StatusMessage
        {
            get
            {
                if (string.IsNullOrEmpty(_statusMessageKey)) return string.Empty;
                return Application.Current.TryFindResource(_statusMessageKey) as string ?? _statusMessageKey;
            }
            private set
            {
                // Check if the key itself has changed.
                // If only the language changes, the key remains the same, 
                // but the resource resolved by the getter will change.
                // We only need to update _statusMessageKey if a *different message* is being set.
                if (_statusMessageKey != value)
                {
                    _statusMessageKey = value;
                    OnPropertyChanged(); // Notify bindings that StatusMessage (the resolved string) might change
                                         // and that _statusMessageKey (if bound) has changed.
                }
                // Always update the display when the setter is called,
                // as either the key changed or we want to force a refresh with the current key.
                UpdateStatusMessageDisplay();
            }
        }

        public Profile()
        {
            InitializeComponent();
            DataContext = this;
            App.CurrentLanguageChanged += HandleLanguageChange; // Corrected to use event name from App.xaml.cs
        }

        protected override void OnClosed(EventArgs e)
        {
            App.CurrentLanguageChanged -= HandleLanguageChange; // Corrected
            base.OnClosed(e);
        }

        private void UpdateStatusMessageDisplay()
        {
            if (StatusMessageTextBlock == null) return;

            if (string.IsNullOrEmpty(_statusMessageKey))
            {
                StatusMessageTextBlock.Text = string.Empty;
                return;
            }

            string localizedMessage = Application.Current.TryFindResource(_statusMessageKey) as string;
            StatusMessageTextBlock.Text = localizedMessage ?? _statusMessageKey;
            StatusMessageTextBlock.Foreground = (_statusMessageKey.ToLower().Contains("error") ||
                                               _statusMessageKey.ToLower().Contains("ошибка") ||
                                               _statusMessageKey.ToLower().Contains("неверный"))
                ? Brushes.Red
                : Brushes.DarkGreen;
        }


        private void Profile_Loaded(object sender, RoutedEventArgs e)
        {
            LoadLanguagesComboBox();

            CurrentEmailTextBlock.Text = Application.Current.TryFindResource("Profile_LoadingText") as string ?? "загрузка...";

            if (UserSession.CurrentUser != null && (UserSession.ActiveRole == "User" || UserSession.ActiveRole == "Admin"))
            {
                // ... (rest of your loading logic, looks fine) ...
                _currentLoggedInUserId = UserSession.CurrentUser.Id;
                _currentLoggedInUserEmail = UserSession.CurrentUser.Email;
                _currentLoggedInUserPasswordHash = UserSession.CurrentUser.PasswordHash;

                if (string.IsNullOrEmpty(_currentLoggedInUserPasswordHash))
                {
                    StatusMessage = "Message_ErrorPasswordData_NoHash";
                    // ... (rest of error handling)
                    SetProfileControlsEnabled(false);
                    MessageBox.Show(
                        Application.Current.TryFindResource("Message_ErrorPasswordData_NoHash_Text") as string ?? "Password data missing.",
                        Application.Current.TryFindResource("Error_SessionDataError_Title") as string ?? "Session Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }

                CurrentEmailTextBlock.Text = _currentLoggedInUserEmail;
                StatusMessage = "Message_ProfileDataLoaded";
                SetProfileControlsEnabled(true);
            }
            // ... (rest of your else if / else blocks)
            else if (UserSession.CurrentDriver != null && UserSession.ActiveRole == "Driver")
            {
                StatusMessage = "Message_ErrorProfileForUsersOnly"; // Ключ
                SetProfileControlsEnabled(false);
                MessageBox.Show(
                    Application.Current.TryFindResource("Message_ErrorProfileForUsersOnly_Text") as string ?? "Profile is for users only.",
                    Application.Current.TryFindResource("Error_AccessDenied_Title") as string ?? "Access Denied",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                this.Close();
            }
            else
            {
                StatusMessage = "Message_ErrorNotAuthenticated"; // Ключ
                SetProfileControlsEnabled(false);
                MessageBox.Show(
                    Application.Current.TryFindResource("Message_ErrorNotAuthenticated_Text") as string ?? "User not authenticated.",
                    Application.Current.TryFindResource("Error_AccessDenied_Title") as string ?? "Access Denied",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                this.Close();
            }
        }

        private void HandleLanguageChange(object sender, EventArgs e)
        {
            string loadingTextKey = "Profile_LoadingText";
            string currentLocalizedLoadingText = Application.Current.TryFindResource(loadingTextKey) as string;

            if (string.IsNullOrEmpty(_currentLoggedInUserEmail) ||
                CurrentEmailTextBlock.Text == "загрузка..." ||
                CurrentEmailTextBlock.Text == "loading..." ||
                (currentLocalizedLoadingText != null && CurrentEmailTextBlock.Text == currentLocalizedLoadingText))
            {
                CurrentEmailTextBlock.Text = currentLocalizedLoadingText ?? "...";
            }
            else
            {
                CurrentEmailTextBlock.Text = _currentLoggedInUserEmail;
            }

            if (!string.IsNullOrEmpty(_statusMessageKey))
            {
                OnPropertyChanged(nameof(StatusMessage)); // Notify that the resolved string value of StatusMessage might have changed
                UpdateStatusMessageDisplay(); // Refresh the TextBlock's text and color
            }

            if (LanguageComboBox != null && App.Language != null && LanguageComboBox.ItemsSource != null)
            {
                var currentLangInList = ((IEnumerable<CultureInfo>)LanguageComboBox.ItemsSource)
                                        .FirstOrDefault(l => l.Equals(App.Language)); // App.Language is CultureInfo
                if (LanguageComboBox.SelectedItem == null || !LanguageComboBox.SelectedItem.Equals(currentLangInList))
                {
                    LanguageComboBox.SelectedItem = currentLangInList;
                }
            }
        }

        private void LoadLanguagesComboBox()
        {
            if (LanguageComboBox == null) return;

            if (App.AvailableLanguages != null && App.AvailableLanguages.Any()) // Corrected to use property name from App.xaml.cs
            {
                LanguageComboBox.ItemsSource = App.AvailableLanguages; // Corrected
                var currentLangInList = App.AvailableLanguages.FirstOrDefault(l => l.Equals(App.Language)); // App.Language is CultureInfo
                LanguageComboBox.SelectedItem = currentLangInList ?? App.Language;

                LanguageComboBox.SelectionChanged -= LanguageComboBox_SelectionChanged;
                LanguageComboBox.SelectionChanged += LanguageComboBox_SelectionChanged;
            }
            else
            {
                LanguageComboBox.IsEnabled = false;
            }
        }

        private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LanguageComboBox.SelectedItem is CultureInfo selectedCulture && !selectedCulture.Equals(App.Language)) // App.Language is CultureInfo
            {
                App.Language = selectedCulture; // This will call the setter in App.xaml.cs
            }
        }

        // ... (SetProfileControlsEnabled, ChangeEmailButton_Click, ChangePasswordButton_Click, IsValidEmail, OnPropertyChanged remain the same)
        private void SetProfileControlsEnabled(bool isEnabled)
        {
            NewEmailTextBox.IsEnabled = isEnabled;
            CurrentPasswordForEmailChangePasswordBox.IsEnabled = isEnabled;
            ChangeEmailButton.IsEnabled = isEnabled;
            CurrentPasswordForPasswordChangePasswordBox.IsEnabled = isEnabled;
            NewPasswordPasswordBox.IsEnabled = isEnabled;
            ConfirmNewPasswordPasswordBox.IsEnabled = isEnabled;
            ChangePasswordButton.IsEnabled = isEnabled;
        }

        private async void ChangeEmailButton_Click(object sender, RoutedEventArgs e)
        {
            if (UserSession.CurrentUser == null || string.IsNullOrEmpty(_currentLoggedInUserPasswordHash))
            {
                StatusMessage = "Message_ErrorUserDataUnavailable";
                return;
            }

            string newEmail = NewEmailTextBox.Text.Trim();
            string currentPassword = CurrentPasswordForEmailChangePasswordBox.Password;

            if (string.IsNullOrWhiteSpace(newEmail) || !IsValidEmail(newEmail))
            {
                StatusMessage = "Message_ErrorInvalidNewEmail";
                return;
            }
            if (string.IsNullOrWhiteSpace(currentPassword))
            {
                StatusMessage = "Message_ErrorCurrentPasswordRequired";
                return;
            }

            if (!BCrypt.Net.BCrypt.Verify(currentPassword, _currentLoggedInUserPasswordHash))
            {
                StatusMessage = "Message_ErrorIncorrectCurrentPassword";
                return;
            }

            try
            {
                using (var context = new AppDbContext())
                {
                    bool emailExists = await context.Users.AnyAsync(u => u.Email.ToLower() == newEmail.ToLower() && u.Id != _currentLoggedInUserId);
                    if (emailExists)
                    {
                        StatusMessage = "Message_ErrorEmailAlreadyExists";
                        return;
                    }

                    var userToUpdate = await context.Users.FindAsync(_currentLoggedInUserId);
                    if (userToUpdate != null)
                    {
                        userToUpdate.Email = newEmail;
                        await context.SaveChangesAsync();

                        if (UserSession.CurrentUser != null) UserSession.CurrentUser.Email = newEmail;
                        _currentLoggedInUserEmail = newEmail;
                        CurrentEmailTextBlock.Text = newEmail;

                        StatusMessage = "Message_EmailChangedSuccessfully";
                        NewEmailTextBox.Clear();
                        CurrentPasswordForEmailChangePasswordBox.Clear();
                    }
                    else
                    {
                        StatusMessage = "Message_ErrorUserNotFoundForUpdate";
                    }
                }
            }
            catch (Exception ex)
            {
                StatusMessage = "Message_ErrorGenericEmailChange";
                // System.Diagnostics.Debug.WriteLine($"Email change error: {ex.ToString()}");
            }
        }

        private async void ChangePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            if (UserSession.CurrentUser == null || string.IsNullOrEmpty(_currentLoggedInUserPasswordHash))
            {
                StatusMessage = "Message_ErrorUserDataUnavailable";
                return;
            }

            string currentPassword = CurrentPasswordForPasswordChangePasswordBox.Password;
            string newPassword = NewPasswordPasswordBox.Password;
            string confirmNewPassword = ConfirmNewPasswordPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(currentPassword)) { StatusMessage = "Message_ErrorCurrentPasswordRequired"; return; }
            if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 8) { StatusMessage = "Message_ErrorNewPasswordMinLength"; return; }
            if (newPassword != confirmNewPassword) { StatusMessage = "Message_ErrorNewPasswordMismatch"; return; }

            if (!BCrypt.Net.BCrypt.Verify(currentPassword, _currentLoggedInUserPasswordHash))
            {
                StatusMessage = "Message_ErrorIncorrectCurrentPassword"; return;
            }

            string newPasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);

            try
            {
                using (var context = new AppDbContext())
                {
                    var userToUpdate = await context.Users.FindAsync(_currentLoggedInUserId);
                    if (userToUpdate != null)
                    {
                        userToUpdate.PasswordHash = newPasswordHash;
                        await context.SaveChangesAsync();

                        if (UserSession.CurrentUser != null) UserSession.CurrentUser.PasswordHash = newPasswordHash;
                        _currentLoggedInUserPasswordHash = newPasswordHash;

                        StatusMessage = "Message_PasswordChangedSuccessfully";
                        CurrentPasswordForPasswordChangePasswordBox.Clear();
                        NewPasswordPasswordBox.Clear();
                        ConfirmNewPasswordPasswordBox.Clear();
                    }
                    else
                    {
                        StatusMessage = "Message_ErrorUserNotFoundForUpdate";
                    }
                }
            }
            catch (Exception ex)
            {
                StatusMessage = "Message_ErrorGenericPasswordChange";
                // System.Diagnostics.Debug.WriteLine($"Password change error: {ex.ToString()}");
            }
        }

        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email.Trim();
            }
            catch { return false; }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}