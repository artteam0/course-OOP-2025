﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3.Data
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string Role { get; set; } = "User";
        public virtual ICollection<TicketPurchase> TicketPurchases { get; set; } = new List<TicketPurchase>();
    }
    public class UserSession
    {
        public static User CurrentUser { get; private set; }
        public static Driver CurrentDriver { get; private set; }
        public static string ActiveRole { get; private set; }
        public static bool IsAdmin
        {
            get
            {
                return CurrentUser != null && CurrentUser.Role == "Admin";
            }
        }
        public static bool IsRegularUser
        {
            get
            {
                return CurrentUser != null && CurrentUser.Role == "User";
            }
        }
        public static bool IsDriver
        {
            get
            {
                return CurrentDriver != null;
            }
        }
        public static bool IsLoggedIn => CurrentUser != null || CurrentDriver != null;
        public static void LoginAsUser(User user)
        {
            if (user == null)
            {
                Logout();
                return;
            }
            Logout();
            CurrentUser = user;
            ActiveRole = user.Role;
        }
        public static void LoginAsDriver(Driver driver)
        {
            if (driver == null)
            {
                Logout();
                return;
            }
            Logout();
            CurrentDriver = driver;
            ActiveRole = driver.Role;
        }
        public static void Logout()
        {
            CurrentUser = null;
            CurrentDriver = null;
            ActiveRole = null;
        }
        public static string GetLoggedInFullName()
        {
            if (CurrentUser != null)
            {
                return $"{CurrentUser.FirstName} {CurrentUser.LastName}";
            }
            if (CurrentDriver != null)
            {
                return $"{CurrentDriver.FirstName} {CurrentDriver.Surname}";
            }
            return "Гость";
        }
    }

}
