﻿using System;
using System.Collections.Generic;

namespace WpfApp3.Data
{
    public class Route
    {
        public int Id { get; set; }
        public string FromCity { get; set; }
        public string ToCity { get; set; }
        public string Time { get; set; }
        public DateTime DepartureTime { get; set; }
        public int Price { get; set; }
        private string _busNumber;
        public string BusNumber
        {
            get => _busNumber;
            set => _busNumber = value;
        }
        public int SeatsAvailable { get; set; }
        public bool HasAirConditioning { get; set; }
        public bool HasWifi { get; set; }
        public bool HasChargingPorts { get; set; }
        public bool HasExtraLuggageSpace { get; set; }
        public bool IsLargeBus { get; set; }
        public bool AllowsPets { get; set; }
        public string DepartureAddress { get; set; }
        public string ArrivalAddress { get; set; }

        public DateTime ExactDepartureTime { get; set; }
        public DateTime ExactArrivalTime { get; set; }
        public TimeSpan Duration { get; set; }

        public int? DriverId { get; set; }
        public Driver Driver { get; set; }
        public string DriverPhoneNumber => Driver?.Phone;
        public string DriverBusModel => Driver?.BusNumber;
        public virtual ICollection<TicketPurchase> TicketPurchases { get; set; } = new List<TicketPurchase>();

        public string DriverName
        {
            get
            {
                System.Diagnostics.Debug.WriteLine($"DriverName GET: RouteId={this.Id}, RouteHashCode={this.GetHashCode()}, DriverId={this.DriverId}, Driver is {(this.Driver == null ? "NULL" : "NOT NULL, HashCode=" + this.Driver.GetHashCode())}");
                if (this.Driver != null)
                {
                    return $"{this.Driver.Surname} {this.Driver.FirstName?.FirstOrDefault()}.";
                }
                else
                {
                    return "Не назначен";
                }
            }
        }
        public void UpdateBusNumber()
        {
            if (Driver != null)
            {
                BusNumber = Driver.BusNumber;
            }
        }
    }
}
