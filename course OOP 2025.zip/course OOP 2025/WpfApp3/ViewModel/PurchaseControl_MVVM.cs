﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.ViewModel;

namespace WpfApp3.ViewModel
{
    public class PurchaseControl_MVVM : INotifyPropertyChanged
    {
        public ObservableCollection<int> SeatCounts { get; } = new ObservableCollection<int> { 1, 2, 3, 4, 5 };
        public ObservableCollection<string> PaymentMethods { get; } = new ObservableCollection<string> { "Карта", "Наличные", "Онлайн" };

        private int _selectedSeatCount = 1;
        public int SelectedSeatCount
        {
            get => _selectedSeatCount;
            set { _selectedSeatCount = value; OnPropertyChanged(); }
        }

        private string _selectedPaymentMethod = "Карта";
        public string SelectedPaymentMethod
        {
            get => _selectedPaymentMethod;
            set { _selectedPaymentMethod = value; OnPropertyChanged(); }
        }
        public Route SelectedRoute { get; set; }
        public User CurrentUser { get; set; }

        public ICommand ConfirmCommand { get; }
        public ICommand CancelCommand { get; }

        public event Action<int, string> OnConfirmed;
        public event Action OnCancelled;

        public PurchaseControl_MVVM()
        {
            ConfirmCommand = new RelayCommand(_ => Confirm());
            CancelCommand = new RelayCommand(_ => Cancel());
        }

        private void Confirm()
        {
            if (CurrentUser == null)
            {
                System.Windows.MessageBox.Show("Пожалуйста, войдите в систему, чтобы совершить покупку.", "Ошибка", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
                return;
            }

            SaveTicketToDatabase();
            OnConfirmed?.Invoke(SelectedSeatCount, SelectedPaymentMethod);
        }


        private void Cancel()
        {
            OnCancelled?.Invoke();
        }

        private void SaveTicketToDatabase()
        {
            if (SelectedRoute == null || CurrentUser == null) return;

            var ticket = new TicketPurchase
            {
                UserId = CurrentUser.Id,
                RouteId = SelectedRoute.Id,
                SeatCount = SelectedSeatCount,
                PurchaseDate = DateTime.Now
            };

            using (var context = new AppDbContext())
            {
                context.TicketPurchases.Add(ticket);
                context.SaveChanges();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

}
