﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.ViewModel;
using WpfApp3.ViewModels;
using WpfApp3.Views;

namespace WpfApp3.ViewModels
{
    public class Enter_MVVM : INotifyPropertyChanged
    {
        private readonly AppDbContext _dbContext = new AppDbContext();
        private string _email;
        private string _errorMessage;

        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }
        private string _password;
        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            Password = ((PasswordBox)sender).Password;
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }
        public ICommand ForgotPasswordCommand { get; }
        public ICommand RegistrationCommand { get; }
        public ICommand AAA {  get; }
        public ICommand SearchRoute {  get; }

        public Enter_MVVM()
        {
            _dbContext = new AppDbContext();

            LoginCommand = new RelayCommand(Login);
            ForgotPasswordCommand = new RelayCommand(OpenForgotPassword);
            RegistrationCommand = new RelayCommand(OpenRegistration);
            AAA = new RelayCommand(OpenAAA);
            SearchRoute = new RelayCommand(OpenSearchRoute);
        }

        private bool CanLogin(object parameter)
        {
            return !string.IsNullOrWhiteSpace(Email) && !string.IsNullOrWhiteSpace(Password);
        }

        private void UpdateLoginCommandCanExecute()
        {
            (LoginCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }

        private void Login(object parameter)
        {
            if (string.IsNullOrWhiteSpace(Email))
            {
                ErrorMessage = "Email обязателен для заполнения.";
                return;
            }
            if (string.IsNullOrWhiteSpace(Password))
            {
                ErrorMessage = "Пароль обязателен для заполнения.";
                return;
            }

            ErrorMessage = string.Empty;
            var user = _dbContext.Users.FirstOrDefault(u => u.Email.ToLower() == Email.ToLower());

            if (user != null)
            {
                if (BCrypt.Net.BCrypt.Verify(Password, user.PasswordHash))
                {
                    UserSession.LoginAsUser(user);

                    Window windowToOpen;
                    if (UserSession.IsAdmin)
                    {
                        windowToOpen = new MainWindow();
                    }
                    else
                    {
                        windowToOpen = new FilterRoute();
                    }
                    OpenWindowAndCloseCurrent(windowToOpen);
                    return;
                }
                else
                {
                    ErrorMessage = "Неверный пароль.";
                    return;
                }
            }
            var driver = _dbContext.Drivers.FirstOrDefault(d => d.Email.ToLower() == Email.ToLower());

            if (driver != null)
            {
                if (BCrypt.Net.BCrypt.Verify(Password, driver.PasswordHash))
                {
                    UserSession.LoginAsDriver(driver);

                    var driverWindow = new DriverPanelWindow();
                    OpenWindowAndCloseCurrent(driverWindow);
                    return;
                }
                else
                {
                    ErrorMessage = "Неверный пароль.";
                    return;
                }
            }
            ErrorMessage = "Пользователь или водитель с таким email не найден.";
        }

        private void OpenAAA(object parameter)
        {
            var aaa = new Window1();
            aaa.Show();
        }
        private void OpenForgotPassword(object parameter)
        {
            var forgotpass = new ForgotPassword();
            OpenWindowAndCloseCurrent(forgotpass);
        }

        private void OpenSearchRoute(object parameter)
        {
            var searchRouteWindow = new MainWindow();
            OpenWindowAndCloseCurrent(searchRouteWindow);
        }
        private void OpenRegistration(object parameter)
        {
            var registration = new Registration();
            OpenWindowAndCloseCurrent(registration);
        }
        private void OpenWindowAndCloseCurrent(Window newWindow)
        {
            WindowManagerService.ShowWindow(newWindow);
            Application.Current.Windows.OfType<Enter>().FirstOrDefault()?.Close();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
