﻿using System;
using System.ComponentModel;
using System.Net.Mail;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.ViewModel;
using WpfApp3.Views;

namespace WpfApp3.ViewModels
{
    public class ForgotPassword_MVVM : INotifyPropertyChanged
    {
        private string _email;
        private string _phone;

        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        public string Phone
        {
            get => _phone;
            set { _phone = value; OnPropertyChanged(); }
        }

        public ICommand ConfirmCommand { get; }
        public ICommand OpenNewWindowCommand { get; }
        public ICommand OpenEnterWindow {  get; }

        private readonly AppDbContext _context;

        public ForgotPassword_MVVM()
        {
            ConfirmCommand = new RelayCommand(Confirm);
            OpenNewWindowCommand = new RelayCommand(OpenLogin);
            OpenEnterWindow = new RelayCommand(OpenEnter);
            _context = new AppDbContext();
        }

        private void Confirm(object parameter)
        {
            if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(Phone))
            {
                MessageBox.Show("Введите Email и номер телефона.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var user = _context.Users.FirstOrDefault(u => u.Email == Email && u.Phone == Phone);
            if (user == null)
            {
                MessageBox.Show("Пользователь с такими данными не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string newPassword = GeneratePassword(10);
            bool emailSent = SendEmail(user.Email, newPassword);

            if (emailSent)
            {
                user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);
                _context.SaveChanges();

                MessageBox.Show("Данные подтверждены. Проверьте вашу почту — туда отправлен новый пароль.", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);

                Application.Current.Windows.OfType<ForgotPassword>().FirstOrDefault()?.Close();
                new Enter().Show();
            }
            else
            {
                MessageBox.Show("Не удалось отправить письмо. Попробуйте позже.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OpenLogin(object parameter)
        {
            new Enter().Show();
            Application.Current.Windows.OfType<ForgotPassword>().FirstOrDefault()?.Close();
        }
        private void OpenEnter(object parameter)
        {
            var enter = new Enter();
            enter.Show();
            Application.Current.Windows.OfType<ForgotPassword>().FirstOrDefault()?.Close();
        }
        private string GeneratePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var sb = new StringBuilder();
            var rnd = new Random();

            for (int i = 0; i < length; i++)
                sb.Append(valid[rnd.Next(valid.Length)]);

            return sb.ToString();
        }

        private bool SendEmail(string toEmail, string newPassword)
        {
            try
            {
                var fromAddress = new MailAddress("kuliashov200@mail.ru", "NextStop Support");
                var toAddress = new MailAddress(toEmail);
                const string fromPassword = "GfL62emypBT2SHrWKvV7";
                const string subject = "Восстановление пароля";
                string body = $"Ваш новый пароль: {newPassword}";

                var smtp = new SmtpClient
                {
                    Host = "smtp.mail.ru",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new System.Net.NetworkCredential(fromAddress.Address, fromPassword)
                };

                using (var message = new MailMessage(fromAddress, toAddress)
                {
                    Subject = subject,
                    Body = body
                })
                {
                    smtp.Send(message);
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка отправки email: " + ex.Message);
                return false;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}