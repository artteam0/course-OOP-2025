﻿    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Input;
    using WpfApp3.Data;
    using WpfApp3.Services;
    using WpfApp3.ViewModels;
    using WpfApp3.Views;

    namespace WpfApp3.ViewModel
    {
        public class FilterRoute_MVVM : INotifyPropertyChanged
        {
            private readonly AppDbContext _dbContext;
            public static event Action<Route> RouteAdded;
            public ObservableCollection<Route> FilteredRoutes { get; set; }
            public ICommand BuyCommand { get; }
            public ICommand AddTripCommand { get; }
            public ICommand ShowPurchaseCommand { get; }
            public ICommand NavigateToMainPageCommand { get; }

            public FilterRoute_MVVM()
            {
                _dbContext = new AppDbContext();

                Routes = new ObservableCollection<Route>();
                BuyCommand = new RelayCommand(ExecuteBuyCommand);
                SwapCommand = new RelayCommand(_ => SwapCities());
                OpenEnterWindow = new RelayCommand(EnterWindow);
                SearchRoute = new RelayCommand(_ => SearchRoutee());
                OpenContactsWindowCommand = new RelayCommand(ContactsOpen);
                FilteredRoutes = new ObservableCollection<Route>();
                OpenTripsWindow = new RelayCommand(TripsOpen);
                LogoutCommand = new RelayCommand(Logout);
                NavigateToMainPageCommand = new RelayCommand(OpenMain);
                //AddTripCommand = new RelayCommand(ExecuteAddTripCommand);
                LoadCities();
                LoadTimeOptions();
                ShowPurchaseCommand = new RelayCommand(param =>
                {
                    if (param is Route route)
                    {
                        RouteBeingPurchased = route;
                        IsPurchaseVisible = true;
                    }
                });
                AdminPanelWindow_MVVM.RouteAdded += OnRouteAdded;
            }
            private void OnRouteAdded(Route newRoute)
            {
                App.Current.Dispatcher.Invoke(() =>
                {
                    Routes.Add(newRoute);
                    if (!CitiesFrom.Contains(newRoute.FromCity))
                        CitiesFrom.Add(newRoute.FromCity);
                    if (!CitiesTo.Contains(newRoute.ToCity))
                        CitiesTo.Add(newRoute.ToCity);
                });
            }


            private ObservableCollection<string> _citiesFrom;
            public ObservableCollection<string> CitiesFrom
            {
                get => _citiesFrom;
                set
                {
                    _citiesFrom = value;
                    OnPropertyChanged(nameof(CitiesFrom));
                }
            }

            private ObservableCollection<string> _citiesTo;
            public ObservableCollection<string> CitiesTo
            {
                get => _citiesTo;
                set
                {
                    _citiesTo = value;
                    OnPropertyChanged(nameof(CitiesTo));
                }
            }

            private ObservableCollection<string> _timeOptions;
            public ObservableCollection<string> TimeOptions
            {
                get => _timeOptions;
                set
                {
                    _timeOptions = value;
                    OnPropertyChanged(nameof(TimeOptions));
                }
            }

            private string _selectedCityFrom;
            public string SelectedCityFrom
            {
                get => _selectedCityFrom;
                set
                {
                    _selectedCityFrom = value;
                    OnPropertyChanged(nameof(SelectedCityFrom));
                }
            }

            private string _selectedCityTo;
            public string SelectedCityTo
            {
                get => _selectedCityTo;
                set
                {
                    _selectedCityTo = value;
                    OnPropertyChanged(nameof(SelectedCityTo));
                }
            }

            private string _noRoutesMessage;
            public string NoRoutesMessage
            {
                get { return _noRoutesMessage; }
                set
                {
                    if (_noRoutesMessage != value)
                    {
                        _noRoutesMessage = value;
                        OnPropertyChanged(nameof(NoRoutesMessage));
                    }
                }
            }

            private DateTime _selectedDate = DateTime.Today;
            public DateTime SelectedDate
            {
                get => _selectedDate;
                set
                {
                    _selectedDate = value;
                    OnPropertyChanged(nameof(SelectedDate));
                }
            }

            private string _selectedTime;
            public string SelectedTime
            {
                get => _selectedTime;
                set
                {
                    _selectedTime = value;
                    OnPropertyChanged(nameof(SelectedTime));
                }
            }

            private bool _isPurchaseVisible;
            public bool IsPurchaseVisible
            {
                get => _isPurchaseVisible;
                set { _isPurchaseVisible = value; OnPropertyChanged(); }
            }

            private Route _routeBeingPurchased;
            public Route RouteBeingPurchased
            {
                get => _routeBeingPurchased;
                set { _routeBeingPurchased = value; OnPropertyChanged(); }
            }

            private ObservableCollection<Route> _routes;
            public ObservableCollection<Route> Routes
            {
                get => _routes;
                set
                {
                    _routes = value;
                    OnPropertyChanged(nameof(Routes));
                }
            }

            private User _currentUser;
            public User CurrentUser
            {
                get => _currentUser;
                set
                {
                    _currentUser = value;
                    OnPropertyChanged(nameof(CurrentUser));
                    OnPropertyChanged(nameof(IsUserLoggedIn));
                    OnPropertyChanged(nameof(IsUserNotLoggedIn));
                }
            }

            public bool IsUserLoggedIn => UserSession.CurrentUser != null;
            public bool IsUserNotLoggedIn => !IsUserLoggedIn;
            public ICommand SwapCommand { get; }
            public ICommand SearchRoute { get; }
            public ICommand OpenEnterWindow { get; }
            public ICommand LogoutCommand { get; }
            public ICommand OpenContactsWindowCommand { get; }
            public ICommand OpenTripsWindow {  get; }


            #region Методы
            private void EnterWindow(object? parameter)
            {
                var enter = new Enter();
                WindowManagerService.ShowWindow(enter);
                Application.Current.Windows.OfType<FilterRoute>().FirstOrDefault()?.Close();
            }
            private void ContactsOpen(object? parameter)
            {
                var cont = new Contacts();
                WindowManagerService.ShowWindow(cont);
                Application.Current.Windows.OfType<FilterRoute>().FirstOrDefault()?.Close();
            }
            private void OpenMain(object? parameter)
            {
                var main = new MainWindow();
                WindowManagerService.ShowWindow(main);
                Application.Current.Windows.OfType<FilterRoute>().FirstOrDefault()?.Close();
            }
            public void NotifyAuthChanged()
            {
                OnPropertyChanged(nameof(IsUserLoggedIn));
            }
            private void TripsOpen(object? parameter)
            {
                var trip = new Trips();
                WindowManagerService.ShowWindow(trip);
                Application.Current.Windows.OfType<FilterRoute>().FirstOrDefault()?.Close();
            }
        public string CurrentUserName => UserSession.GetLoggedInFullName();
        public string CurrentUserRole => UserSession.ActiveRole;
        private void Logout(object obj)
            {
                var result = MessageBox.Show("Данные во вкладке «Поездки» не сохраняются.", "Вы действительно хотите выйти из аккаунта?",
                                        MessageBoxButton.YesNo,
                                        MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                UserSession.Logout();
                OnPropertyChanged(nameof(IsUserLoggedIn));
                OnPropertyChanged(nameof(IsUserNotLoggedIn));
                OnPropertyChanged(nameof(CurrentUserName));
                OnPropertyChanged(nameof(CurrentUserRole));
                var mainWindow = new MainWindow();
                    mainWindow.Show();
                    Application.Current.Windows.OfType<FilterRoute>().FirstOrDefault()?.Close();
                }
            }
            private void ExecuteBuyCommand(object parameter)
            {
                if (!UserSession.IsLoggedIn)
                {
                    MessageBox.Show("Пожалуйста, войдите в систему");
                    return;
                }

                if (parameter is Route selectedRoute)
                {
                    SelectedRouteService.AddRoute(selectedRoute);
                    MessageBox.Show("Маршрут добавлен в поездку");
                }
            }
            //private void ExecuteAddTripCommand(object parameter)
            //{
            //    if (!UserSession.IsLoggedIn)
            //    {
            //        MessageBox.Show("Пожалуйста, войдите в систему");
            //        return;
            //    }

            //    if (parameter is Route selectedRoute)
            //    {
            //        TripService.AddTrip(selectedRoute);
            //        MessageBox.Show("Маршрут добавлен в поездки!");
            //    }
            //}
            private void LoadCities(string from = null, string to = null)
            {
            var routesList = _dbContext.Routes
                        .Include(r => r.Driver)
                        .ToList();
            foreach (var route in routesList)
            {
                Routes.Add(route);
            }
            if (Routes == null || !Routes.Any())
                {
                    CitiesFrom = new ObservableCollection<string>();
                    CitiesTo = new ObservableCollection<string>();
                    return;
                }

                var allCities = Routes
                    .SelectMany(r => new[] { r.FromCity, r.ToCity })
                    .Where(c => !string.IsNullOrWhiteSpace(c))
                    .Distinct()
                    .OrderBy(c => c)
                    .ToList();

                CitiesFrom = new ObservableCollection<string>(allCities);
                CitiesTo = new ObservableCollection<string>(allCities);

                SelectedCityFrom = from ?? CitiesFrom.FirstOrDefault();
                SelectedCityTo = to ?? CitiesTo.FirstOrDefault();
            }


            private void LoadTimeOptions()
            {
                TimeOptions = new ObservableCollection<string>
                {
                    "Любое",
                    "Утро",
                    "День",
                    "Вечер",
                    "Ночь"
                };

                SelectedTime = TimeOptions.FirstOrDefault();
            }

            private void SwapCities()
            {
                (SelectedCityFrom, SelectedCityTo) = (SelectedCityTo, SelectedCityFrom);
            }

            private async void SearchRoutee()
            {
                try
                {
                    if (string.IsNullOrEmpty(SelectedCityFrom) || string.IsNullOrEmpty(SelectedCityTo))
                        throw new ArgumentException("Не выбрано место отправления или назначения");

                    if (string.IsNullOrEmpty(SelectedTime))
                        throw new ArgumentException("Не выбрано время");

                var query = _dbContext.Routes
                            .Include(r => r.Driver) 
                            .Where(r => r.FromCity == SelectedCityFrom && r.ToCity == SelectedCityTo && r.DepartureTime.Date == SelectedDate.Date);

                if (SelectedTime != "Любое" && !string.IsNullOrEmpty(SelectedTime))
                    {
                        query = query.Where(r => r.Time == SelectedTime);
                    }

                    var routes = await query.OrderBy(r => r.DepartureTime).ToListAsync();

                    Routes = new ObservableCollection<Route>(routes);

                    if (!Routes.Any())
                    {
                        NoRoutesMessage = "Маршруты не найдены";
                    }
                    else
                    {
                        NoRoutesMessage = string.Empty;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при поиске маршрутов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            #endregion

            #region INotifyPropertyChanged

            public event PropertyChangedEventHandler PropertyChanged;
            protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }

            #endregion

            public void SearchFromMain(string from, string to, DateTime date, string time)
            {
                SelectedDate = date;
                SelectedTime = time;

                LoadCities(from, to);
                SearchRoutee();
            }

        }
    }
