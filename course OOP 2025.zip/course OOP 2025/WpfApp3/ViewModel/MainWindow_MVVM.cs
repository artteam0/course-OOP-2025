﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.Views;
using System.Collections.Generic;

namespace WpfApp3.ViewModel
{
    public class MainWindow_MVVM : INotifyPropertyChanged
    {
        private readonly AppDbContext _dbContext;

        private readonly Dictionary<(string from, string to), int> CityDistances = new Dictionary<(string, string), int>
        {
            { ("Минск", "Гомель"), 302 },
            { ("Минск", "Витебск"), 272 },
            { ("Минск", "Брест"), 350 },
            { ("Минск", "Гродно"), 270 },
            { ("Минск", "Могилёв"), 210 },
            { ("Гомель", "Витебск"), 515 },
            { ("Гомель", "Брест"), 520 },
            { ("Гомель", "Гродно"), 600 },
            { ("Гомель", "Могилёв"), 140 },
            { ("Витебск", "Брест"), 660 },
            { ("Витебск", "Гродно"), 580 },
            { ("Витебск", "Могилёв"), 120 },
            { ("Брест", "Гродно"), 230 },
            { ("Брест", "Могилёв"), 470 },
            { ("Гродно", "Могилёв"), 390 },

            { ("Минск", "Москва"), 715 },
            { ("Минск", "Санкт-Петербург"), 900 },
            { ("Минск", "Смоленск"), 360 },
            { ("Минск", "Воронеж"), 490 },
            { ("Минск", "Великий Новгород"), 520 },
            { ("Минск", "Калуга"), 500 },
            { ("Минск", "Рязань"), 610 }
        };

        public ObservableCollection<Route> Routes { get; set; } = new ObservableCollection<Route>();

        public bool IsAdmin => UserSession.IsAdmin;
        public Visibility IsAdminVisible => IsAdmin ? Visibility.Visible : Visibility.Collapsed;
        public bool IsDriver => UserSession.IsDriver;
        public Visibility IsDriverVisible => IsDriver ? Visibility.Visible : Visibility.Collapsed;

        public ICommand OpenAdminPanelCommand { get; }
        public ICommand OpenDriverPanelCommand { get; }

        public MainWindow_MVVM()
        {
            _dbContext = new AppDbContext();

            if (!_dbContext.Routes.Any())
                SeedTestData();
            AdminPanelWindow_MVVM.RouteAdded += OnRouteAdded;
            LoadCitiesFromRoutes();
            LoadCitiesAsync();


            FromCity = "";
            ToCity = "";
            TIME = "";

            SwapCommand = new RelayCommand(_ => (FromCity, ToCity) = (ToCity, FromCity));
            OpenEnterWindow = new RelayCommand(OpenEnter);
            SearchRoutesCommand = new RelayCommand(SearchRoutes);
            OpenAdminPanelCommand = new RelayCommand(OpenAdminPanel);
            OpenDriverPanelCommand = new RelayCommand(OpenDriverPanel);
            LogoutCommand = new RelayCommand(Logout);
        }
        private void OnRouteAdded(Route newRoute)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                Routes.Add(newRoute);

                if (!CitiesFrom.Contains(newRoute.FromCity))
                    CitiesFrom.Add(newRoute.FromCity);
                if (!CitiesTo.Contains(newRoute.ToCity))
                    CitiesTo.Add(newRoute.ToCity);
            });
        }

        private void LoadCitiesFromRoutes()
        {
            var fromCities = Routes.Select(r => r.FromCity).Distinct().OrderBy(c => c).ToList();
            var toCities = Routes.Select(r => r.ToCity).Distinct().OrderBy(c => c).ToList();

            CitiesFrom.Clear();
            foreach (var city in fromCities)
                CitiesFrom.Add(city);

            CitiesTo.Clear();
            foreach (var city in toCities)
                CitiesTo.Add(city);
        }

        ~MainWindow_MVVM()
        {
            AdminPanelWindow_MVVM.RouteAdded -= OnRouteAdded;
        }
        private async void LoadCitiesAsync()
        {
            try
            {
                var citiesFrom = await _dbContext.Routes
                    .Select(r => r.FromCity)
                    .Distinct()
                    .OrderBy(city => city)
                    .ToListAsync();

                var citiesTo = await _dbContext.Routes
                    .Select(r => r.ToCity)
                    .Distinct()
                    .OrderBy(city => city)
                    .ToListAsync();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    CitiesFrom.Clear();
                    foreach (var city in citiesFrom)
                        CitiesFrom.Add(city);

                    CitiesTo.Clear();
                    foreach (var city in citiesTo)
                        CitiesTo.Add(city);
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки городов: {ex.Message}");
            }
        }
        public ObservableCollection<string> CitiesFrom { get; } = new ObservableCollection<string>();
        public ObservableCollection<string> CitiesTo { get; } = new ObservableCollection<string>();
        public ObservableCollection<string> TimeOptions { get; } = new ObservableCollection<string>() { "Утро", "День", "Вечер", "Ночь" };

        private string _fromCity;
        public string FromCity { get => _fromCity; set { _fromCity = value; OnPropertyChanged(); } }

        private string _toCity;
        public string ToCity { get => _toCity; set { _toCity = value; OnPropertyChanged(); } }

        private string _time;
        public string TIME { get => _time; set { _time = value; OnPropertyChanged(); } }

        private DateTime _selectedDate = DateTime.Today;
        public DateTime SelectedDate { get => _selectedDate; set { _selectedDate = value; OnPropertyChanged(); } }

        public ICommand SwapCommand { get; }
        public ICommand OpenEnterWindow { get; }
        public ICommand SearchRoutesCommand { get; }
        public ICommand LogoutCommand { get; }
        public bool IsUserLoggedIn => UserSession.CurrentUser != null;
        public bool IsUserNotLoggedIn => !IsUserLoggedIn;
        public string CurrentUserName => UserSession.GetLoggedInFullName();
        public string CurrentUserRole => UserSession.ActiveRole;
        private void Logout(object obj)
        {
            var result = MessageBox.Show("Вы покидаете сессию админа.", "Вы действительно хотите выйти из аккаунта?",
                                    MessageBoxButton.YesNo,
                                    MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                UserSession.Logout();
                OnPropertyChanged(nameof(IsUserLoggedIn));
                OnPropertyChanged(nameof(IsUserNotLoggedIn));
                OnPropertyChanged(nameof(CurrentUserName));
                OnPropertyChanged(nameof(CurrentUserRole));
                var mainWindow = new MainWindow();
                mainWindow.Show();
                Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()?.Close();
            }
        }
        private void OpenEnter(object? param)
        {
            var enter = new Enter();
            WindowManagerService.ShowWindow(enter);
            Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()?.Close();
        }

        private void OpenAdminPanel(object obj)
        {
            var adminWindow = new AdminPanelWindow();
            WindowManagerService.ShowWindow(adminWindow);
            Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()?.Close();
        }
        private void OpenDriverPanel(object obj)
        {
            var adminWindow = new DriverPanelWindow();
            WindowManagerService.ShowWindow(adminWindow);
            Application.Current.Windows.OfType<MainWindow>().FirstOrDefault()?.Close();
        }
        private async void SearchRoutes(object? param)
        {
            try
            {
                if (string.IsNullOrEmpty(FromCity)) throw new ArgumentException("Не выбрано место отправления");
                if (string.IsNullOrEmpty(ToCity)) throw new ArgumentException("Не выбрано место назначения");
                if (string.IsNullOrEmpty(TIME)) throw new ArgumentException("Не выбрано время");
                if (FromCity == ToCity) throw new ArgumentException("Города отправления и назначения не могут совпадать");

                var routes = await Task.Run(() =>
                    _dbContext.Routes
                        .Where(r => r.FromCity == FromCity && r.ToCity == ToCity && r.Time == TIME && r.DepartureTime.Date == SelectedDate.Date)
                        .OrderBy(r => r.DepartureTime)
                        .ToList()
                );

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Routes.Clear();
                    foreach (var route in routes)
                        Routes.Add(route);
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка поиска: {ex.Message}");
            }
        }

        private void SeedTestData()
        {
            if (_dbContext.Routes.Any()) return;

            string[] belarusCities = { "Минск", "Гомель", "Витебск", "Брест", "Гродно", "Могилёв" };
            string[] russiaCities = { "Москва", "Санкт-Петербург", "Смоленск", "Воронеж", "Великий Новгород", "Калуга", "Рязань" };
            string[] timeOptions = { "Утро", "День", "Вечер", "Ночь" };

            var random = new Random();
            DateTime today = DateTime.Today;
            var routes = new List<Route>();

            foreach (var from in belarusCities)
            {
                foreach (var to in belarusCities)
                {
                    if (from == to) continue;
                    for (int i = 0; i < 7; i++)
                    {
                        var date = today.AddDays(i);
                        int routeCountPerDay = random.Next(5, 10);
                        for (int j = 0; j < routeCountPerDay; j++)
                        {
                            var time = timeOptions[random.Next(timeOptions.Length)];
                            routes.Add(GenerateRoute(from, to, time, date, random, isLongDistance: false));
                        }
                    }
                }
            }

            foreach (var from in belarusCities)
            {
                foreach (var to in russiaCities)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        var date = today.AddDays(i);
                        int routeCountPerDay = random.Next(5, 10);
                        for (int j = 0; j < routeCountPerDay; j++)
                        {
                            var time = timeOptions[random.Next(timeOptions.Length)];
                            routes.Add(GenerateRoute(from, to, time, date, random, isLongDistance: true));
                        }
                    }
                }
            }

            _dbContext.Routes.AddRange(routes);
            _dbContext.SaveChanges();
        }

        private Route GenerateRoute(string from, string to, string timeSlot, DateTime date, Random random, bool isLongDistance)
        {
            var departureTime = GetDepartureTimeBySlot(timeSlot, random);
            var duration = GetDuration(random, isLongDistance);
            var arrivalTime = departureTime + duration;
            int distance = GetDistance(from, to);
            int price = CalculatePriceByDistance(distance, random);

            return new Route
            {
                FromCity = from,
                ToCity = to,
                Time = timeSlot,
                DepartureTime = date,
                ExactDepartureTime = date.Date + departureTime,
                ExactArrivalTime = date.Date + arrivalTime,
                Duration = duration,
                DepartureAddress = $"{from}, Автостанция {random.Next(1, 15)}",
                ArrivalAddress = $"{to}, Автостанция {random.Next(1, 15)}",
                Price = price,
                BusNumber = $"АК{random.Next(1000, 9999)}",
                SeatsAvailable = random.Next(10, 50),
                HasAirConditioning = random.Next(2) == 1,
                HasWifi = random.Next(2) == 1,
                HasChargingPorts = random.Next(2) == 1,
                HasExtraLuggageSpace = random.Next(2) == 1,
                IsLargeBus = random.Next(2) == 1,
                AllowsPets = random.Next(2) == 1
            };
        }
        private int GetDistance(string from, string to)
        {
            if (from == to) return 0;

            if (CityDistances.TryGetValue((from, to), out int distance))
                return distance;
            if (CityDistances.TryGetValue((to, from), out distance))
                return distance;
            return 300;
        }

        private int CalculatePriceByDistance(int distance, Random rnd)
        {
            double basePrice = 10;
            double pricePerKm = 0.075;

            double price = basePrice + (distance * pricePerKm) + rnd.NextDouble() * 5;

            return (int)Math.Round(price);
        }

        private TimeSpan GetDepartureTimeBySlot(string slot, Random rnd)
        {
            return slot switch
            {
                "Утро" => new TimeSpan(rnd.Next(6, 12), rnd.Next(0, 60), 0),
                "День" => new TimeSpan(rnd.Next(12, 18), rnd.Next(0, 60), 0),
                "Вечер" => new TimeSpan(rnd.Next(18, 24), rnd.Next(0, 60), 0),
                "Ночь" => new TimeSpan(rnd.Next(0, 6), rnd.Next(0, 60), 0),
                _ => new TimeSpan(12, 0, 0)
            };
        }

        private TimeSpan GetDuration(Random rnd, bool isLongDistance)
        {
            return isLongDistance
                ? TimeSpan.FromMinutes(rnd.Next(300, 600)) // 5–10 часов
                : TimeSpan.FromMinutes(rnd.Next(120, 300)); // 2–5 часов
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = "") =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
