﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.ViewModels;
using WpfApp3.Views;

namespace WpfApp3.ViewModel
{
    public class Contacts_MVVM
    {
        public ICommand OpenVKCommand { get; }
        public ICommand OpenTelegramCommand { get; }
        public ICommand OpenInstagramCommand { get; }
        public ICommand NavigateToMainPageCommand { get; }
        public ICommand Back {  get; }
        public Contacts_MVVM()
        {
            OpenVKCommand = new RelayCommand(_ => OpenUrl("https://vk.com/yourpage"));
            OpenTelegramCommand = new RelayCommand(_ => OpenUrl("https://t.me/yourchannel"));
            OpenInstagramCommand = new RelayCommand(_ => OpenUrl("https://instagram.com/yourprofile"));
            NavigateToMainPageCommand = new RelayCommand(OpenMainPage);
            Back = new RelayCommand(BackPage);
        }

        private void OpenUrl(string url)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            });
        }
        private void OpenMainPage(object? parameter)
        {
            var main = new MainWindow();
            WindowManagerService.ShowWindow(main);
            Application.Current.Windows.OfType<Contacts>().FirstOrDefault()?.Close();
        }
        private void BackPage(object? parameter)
        {
            var filt = new FilterRoute();
            WindowManagerService.ShowWindow(filt);
            Application.Current.Windows.OfType<Contacts>().FirstOrDefault()?.Close();
        }
    }
}
