﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.ViewModel;
using WpfApp3.ViewModels;
using WpfApp3.Views;

namespace WpfApp3.ViewModels
{
    public class Registration_MVVM : INotifyPropertyChanged
    {
        private readonly AppDbContext _dbContext;
        public string FirstName { get => _firstName; set { _firstName = Capitalize(value); OnPropertyChanged(); } }
        public string LastName { get => _lastName; set { _lastName = Capitalize(value); OnPropertyChanged(); } }
        public string Phone { get => _phone; set { _phone = value; OnPropertyChanged(); } }
        public string Email { get => _email; set { _email = value; OnPropertyChanged(); } }
        public bool AgreementAccepted { get => _agreementAccepted; set { _agreementAccepted = value; OnPropertyChanged(); } }
        public string ErrorMessage { get => _errorMessage; set { _errorMessage = value; OnPropertyChanged(); } }

        private string _firstName, _lastName, _phone, _email, _errorMessage;
        private bool _agreementAccepted;

        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();
        public ICommand RegisterCommand { get; }
        public ICommand OpenEnterWindow {  get; }

        public Registration_MVVM()
        {
            _dbContext = new AppDbContext();
            RegisterCommand = new RelayCommand(RegisterUser);
            OpenEnterWindow = new RelayCommand(EnterWindow);
        }

        private void RegisterUser(object obj)
        {
            ErrorMessage = string.Empty;

            var passwordBox = obj as System.Windows.Controls.PasswordBox;
            string password = passwordBox?.Password;

            if (!AgreementAccepted)
            {
                ErrorMessage = "Вы должны принять пользовательское соглашение.";
                return;
            }
            if (string.IsNullOrWhiteSpace(FirstName))
            {
                ErrorMessage = "Введите имя.";
                return;
            }
            if (string.IsNullOrWhiteSpace(LastName))
            {
                ErrorMessage = "Введите фамилию.";
                return;
            }
            if (string.IsNullOrWhiteSpace(Phone))
            {
                ErrorMessage = "Введите номер телефона.";
                return;
            }
            if (string.IsNullOrWhiteSpace(Email) || !Email.Contains("@"))
            {
                ErrorMessage = "Введите корректный Email.";
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                ErrorMessage = "Введите пароль.";
                return;
            }
            if (_dbContext.Users.Any(u => u.Email == Email))
            {
                ErrorMessage = "Пользователь с таким Email уже существует.";
                return;
            }

            string role = "User";
            if (Email.ToLower() == "kuliashov200@mail.ru" && password == "admin_123456789")
            {
                role = "Admin";
            }

            var user = new User
            {
                FirstName = FirstName,
                LastName = LastName,
                Phone = Phone,
                Email = Email,
                PasswordHash = HashPassword(password),
                Role = role
            };

            _dbContext.Users.Add(user);
            _dbContext.SaveChanges();

            UserSession.LoginAsUser(user);

            Application.Current.Dispatcher.Invoke(() =>
            {
                var currentWindow = Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w.IsActive);

                var filterRouteWindow = new FilterRoute();

                if (filterRouteWindow.DataContext is FilterRoute_MVVM vm)
                {
                    vm.CurrentUser = user;
                }

                filterRouteWindow.Show();
                currentWindow?.Close();
            });
        }

        private void EnterWindow(object parameter)
        {
            var enter = new Enter();
            WindowManagerService.ShowWindow(enter);
            Application.Current.Windows.OfType<Registration>().FirstOrDefault()?.Close();
        }
        private string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        private string Capitalize(string value) =>
            string.IsNullOrWhiteSpace(value) ? value :
            char.ToUpper(value[0]) + value.Substring(1).ToLower();

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
