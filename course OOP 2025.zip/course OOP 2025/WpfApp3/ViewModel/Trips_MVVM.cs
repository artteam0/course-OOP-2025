﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.ViewModels;
using WpfApp3.Views;

namespace WpfApp3.ViewModel
{
    using Microsoft.EntityFrameworkCore;

    public class Trips_MVVM : INotifyPropertyChanged
    {
        private readonly AppDbContext _context;

        public ObservableCollection<Route> BoughtRoutes { get; set; }
        public ICommand Back { get; }
        public ICommand RemoveRouteCommand { get; }
        public ICommand NavigateToMainPageCommand { get;}

        public Trips_MVVM()
        {
            _context = new AppDbContext();

            LoadBoughtRoutesFromDb();

            RemoveRouteCommand = new RelayCommand(RemoveRoute);
            NavigateToMainPageCommand = new RelayCommand(OpenMain);
            Back = new RelayCommand(BackPage);
        }

        private void LoadBoughtRoutesFromDb()
        {
            if (UserSession.CurrentUser == null)
            {
                BoughtRoutes = new ObservableCollection<Route>();
                return;
            }

            var userId = UserSession.CurrentUser.Id;
            var ticketsWithRoutes = _context.TicketPurchases
                .Where(t => t.UserId == userId)
                .Select(t => t.Route)
                .Distinct()
                .ToList();

            BoughtRoutes = new ObservableCollection<Route>(ticketsWithRoutes);
            OnPropertyChanged(nameof(BoughtRoutes));
        }

        private void RemoveRoute(object? parameter)
        {
            if (parameter is Route route)
            {
                _context.Routes.Remove(route);
                _context.SaveChanges();

                BoughtRoutes.Remove(route);
            }
        }

        private void BackPage(object? parameter)
        {
            var filt = new FilterRoute();
            WindowManagerService.ShowWindow(filt);
            Application.Current.Windows.OfType<Trips>().FirstOrDefault()?.Close();
        }

        private void OpenMain(object? parameter)
        {
            var main = new MainWindow();
            WindowManagerService.ShowWindow(main);
            Application.Current.Windows.OfType<Trips>().FirstOrDefault()?.Close();
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
    }
}
