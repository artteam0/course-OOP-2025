﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3.Data;

namespace WpfApp3.ViewModel
{
    public class AdminRoutesViewModel : ViewModelBase
    {
        public ObservableCollection<Route> Routes { get; set; } = new ObservableCollection<Route>();

        public AdminRoutesViewModel()
        {
            LoadRoutes();
        }

        private void LoadRoutes()
        {
            // Подключение к базе данных и загрузка маршрутов
            using (SqlConnection connection = new SqlConnection("YourConnectionString"))
            {
                connection.Open();
                var query = "SELECT * FROM Routes";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Routes.Add(new Route
                            {
                                Id = (int)reader["Id"],
                                FromCity = (string)reader["FromCity"],
                                ToCity = (string)reader["ToCity"],
                                Time = (string)reader["Time"],
                                DepartureTime = (DateTime)reader["DepartureTime"],
                                Price = (int)reader["Price"],
                                BusNumber = (string)reader["BusNumber"],
                                SeatsAvailable = (int)reader["SeatsAvailable"],
                                HasAirConditioning = (bool)reader["HasAirConditioning"],
                                HasWifi = (bool)reader["HasWifi"],
                                HasChargingPorts = (bool)reader["HasChargingPorts"],
                                HasExtraLuggageSpace = (bool)reader["HasExtraLuggageSpace"],
                                IsLargeBus = (bool)reader["IsLargeBus"],
                                AllowsPets = (bool)reader["AllowsPets"],
                                DepartureAddress = (string)reader["DepartureAddress"],
                                ArrivalAddress = (string)reader["ArrivalAddress"],
                                ExactDepartureTime = (DateTime)reader["ExactDepartureTime"],
                                ExactArrivalTime = (DateTime)reader["ExactArrivalTime"]
                            });
                        }
                    }
                }
            }
        }
    }
}
