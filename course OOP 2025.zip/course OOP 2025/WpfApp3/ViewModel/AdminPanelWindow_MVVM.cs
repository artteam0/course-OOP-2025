﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.ViewModels;
using WpfApp3.Views;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp3.ViewModel
{
    public class AdminPanelWindow_MVVM : INotifyPropertyChanged
    {
        private readonly AppDbContext _dbContext;

        public AdminPanelWindow_MVVM()
        {
            _dbContext = new AppDbContext();

            Routes = new ObservableCollection<Route>();
            Drivers = new ObservableCollection<Driver>();
            NoRoutesMessage = string.Empty;

            LoadRoutesCommand = new RelayCommand(async _ => await LoadRoutes());
            LoadDriversCommand = new RelayCommand(async _ => await LoadDrivers());
            NoRoutesMessage = string.Empty;
            ToggleRoutesVisibilityCommand = new RelayCommand(_ => ToggleRoutesVisibility());
            ToggleDriverPanelCommand = new RelayCommand(_ => ToggleDriverPanelVisibility());
            ToggleDriversVisibilityCommand = new RelayCommand(_ => LoadAndToggleDrivers());
            LoadAndToggleRoutesCommand = new RelayCommand(async _ => await LoadAndToggleRoutes());
            EditRouteCommand = new RelayCommand(route => SelectedRoute = route as Route);
            SaveEditedRouteCommand = new RelayCommand(async _ => await SaveEditedRoute());
            DeleteRouteCommand = new RelayCommand(async _ => await DeleteRoute());
            ShowAddRouteFormCommand = new RelayCommand(_ => ShowAddRouteForm());
            SaveNewRouteCommand = new RelayCommand(async _ => await SaveNewRoute());
            CancelAddRouteCommand = new RelayCommand(_ => CancelAddRoute());
            NavigateToMainPageCommand = new RelayCommand(NavigateToMainPage);
            SaveDriverCommand = new RelayCommand(SaveDriver);
            //EditDriverCommand = new RelayCommand(driver => SelectedDriver = driver as Driver);
            SaveEditedDriverCommand = new RelayCommand(async _ => await SaveEditedDriver());
            DeleteDriverCommand = new RelayCommand(async _ => await DeleteDriver());
            LoadDriversCommand.Execute(true);
            SwapCommand = new RelayCommand(_ => SwapCities());
            SearchRoute = new RelayCommand(_ => SearchRoutee());
            CloseAddDriverCommand = new RelayCommand(_ => CloseAddDriver());
            LoadCities();
            LoadTimeOptions();
            NewRoute = new Route
            {
                DepartureTime = new DateTime(2025, 5, 9, 12, 0, 0)
            };
        }

        #region Свойства

        private ObservableCollection<Route> _routes;
        private ObservableCollection<Driver> _drivers;
        public ObservableCollection<Route> Routes
        {
            get => _routes;
            set { _routes = value; OnPropertyChanged(); }
        }
        public ObservableCollection<Driver> Drivers
        {
            get => _drivers;
            set { _drivers = value; OnPropertyChanged(); }
        }
        private string _noRoutesMessage;
        public string NoRoutesMessage
        {
            get => _noRoutesMessage;
            set { _noRoutesMessage = value; OnPropertyChanged(); }
        }

        private bool _isRoutesVisible;
        public bool IsRoutesVisible
        {
            get => _isRoutesVisible;
            set
            {
                _isRoutesVisible = value;
                OnPropertyChanged();
                IsAddRouteButtonVisible = value;
            }
        }
        private bool _isAddRouteButtonVisible;
        public bool IsAddRouteButtonVisible
        {
            get => _isAddRouteButtonVisible;
            set { _isAddRouteButtonVisible = value; OnPropertyChanged(); }
        }

        private bool _isDriverPanelVisible;
        public bool IsDriverPanelVisible
        {
            get => _isDriverPanelVisible;
            set { _isDriverPanelVisible = value; OnPropertyChanged(); }
        }

        private bool _isAddDriverFormVisible;
        public bool IsAddDriverFormVisible
        {
            get => _isAddDriverFormVisible;
            set
            {
                _isAddDriverFormVisible = value;
                OnPropertyChanged();
            }
        }

        private Driver _selectedDriver;
        public Driver SelectedDriver
        {
            get => _selectedDriver;
            set
            {
                _selectedDriver = value;
                OnPropertyChanged();
                IsEditDriverFormVisible = value != null;

            }
        }

        private bool _isEditDriverFormVisible;
        public bool IsEditDriverFormVisible
        {
            get => _isEditDriverFormVisible;
            set
            {
                _isEditDriverFormVisible = value;
                OnPropertyChanged();
            }
        }
        private Route _selectedRoute;
        public Route SelectedRoute
        {
            get => _selectedRoute;
            set
            {
                _selectedRoute = value;
                OnPropertyChanged();
                IsEditPanelVisible = value != null;
                if (_selectedRoute != null)
                {
                    EditedDepartureTime = _selectedRoute.DepartureTime;
                    SelectedDriverForRoute = Drivers.FirstOrDefault(d => d.Id == _selectedRoute.DriverId);
                    OnPropertyChanged(nameof(SelectedDriverForRoute));
                }
                else
                {
                    SelectedDriverForRoute = null;
                    OnPropertyChanged(nameof(SelectedDriverForRoute));
                }
            }
        }

        private bool _isEditPanelVisible;
        public bool IsEditPanelVisible
        {
            get => _isEditPanelVisible;
            set { _isEditPanelVisible = value; OnPropertyChanged(); }
        }

        private DateTime _editedDepartureTime;
        public DateTime EditedDepartureTime
        {
            get => _editedDepartureTime;
            set
            {
                if (_selectedRoute != null && _editedDepartureTime != value)
                {
                    _editedDepartureTime = value;
                    OnPropertyChanged();
                }
            }
        }

        private bool _isAddRouteFormVisible;
        public bool IsAddRouteFormVisible
        {
            get => _isAddRouteFormVisible;
            set
            {
                if (_isAddRouteFormVisible != value)
                {
                    _isAddRouteFormVisible = value;
                    OnPropertyChanged();
                }
            }
        }

        private Route _newRoute = new Route();
        public Route NewRoute
        {
            get => _newRoute;
            set { _newRoute = value; OnPropertyChanged(); }
        }
        private Driver _newDriver = new Driver();
        public Driver newDriver
        {
            get => _newDriver;
            set { _newDriver = value; OnPropertyChanged(); }
        }

        private Driver _selectedDriverForRoute;
        public Driver SelectedDriverForRoute
        {
            get => _selectedDriverForRoute;
            set
            {
                _selectedDriverForRoute = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<string> _citiesFrom;
        public ObservableCollection<string> CitiesFrom
        {
            get => _citiesFrom;
            set
            {
                _citiesFrom = value;
                OnPropertyChanged(nameof(CitiesFrom));
            }
        }

        private ObservableCollection<string> _citiesTo;
        public ObservableCollection<string> CitiesTo
        {
            get => _citiesTo;
            set
            {
                _citiesTo = value;
                OnPropertyChanged(nameof(CitiesTo));
            }
        }

        private ObservableCollection<string> _timeOptions;
        public ObservableCollection<string> TimeOptions
        {
            get => _timeOptions;
            set
            {
                _timeOptions = value;
                OnPropertyChanged(nameof(TimeOptions));
            }
        }

        private string _selectedCityFrom;
        public string SelectedCityFrom
        {
            get => _selectedCityFrom;
            set
            {
                _selectedCityFrom = value;
                OnPropertyChanged(nameof(SelectedCityFrom));
            }
        }

        private string _selectedCityTo;
        public string SelectedCityTo
        {
            get => _selectedCityTo;
            set
            {
                _selectedCityTo = value;
                OnPropertyChanged(nameof(SelectedCityTo));
            }
        }

        private DateTime _selectedDate = DateTime.Today;
        public DateTime SelectedDate
        {
            get => _selectedDate;
            set
            {
                _selectedDate = value;
                OnPropertyChanged(nameof(SelectedDate));
            }
        }

        private string _selectedTime;
        public string SelectedTime
        {
            get => _selectedTime;
            set
            {
                _selectedTime = value;
                OnPropertyChanged(nameof(SelectedTime));
            }
        }

        #endregion

        #region Команды

        public ICommand LoadRoutesCommand { get; }
        public ICommand LoadAndToggleRoutesCommand { get; }
        public ICommand ToggleRoutesVisibilityCommand { get; }
        public ICommand ToggleDriversVisibilityCommand { get; }
        public ICommand EditRouteCommand { get; }
        public ICommand SaveEditedRouteCommand { get; }
        public ICommand DeleteRouteCommand { get; }
        public ICommand ShowAddRouteFormCommand { get; }
        public ICommand SaveNewRouteCommand { get; }
        public ICommand CancelAddRouteCommand { get; }
        public ICommand NavigateToMainPageCommand { get; }
        public ICommand ToggleDriverPanelCommand { get; }
        public ICommand LoadDriversCommand { get; }
        public Driver NewDriver { get; set; } = new Driver();
        public string Password { get; set; }
        public ICommand SaveDriverCommand { get; }
        public ICommand SaveEditedDriverCommand { get; }
        public ICommand DeleteDriverCommand { get; }
        //public ICommand EditDriverCommand { get; }
        public ICommand SwapCommand { get; }
        public ICommand SearchRoute { get; }
        public ICommand CloseAddDriverCommand { get; }
        public ICommand ShowAddDriverFormCommand => new RelayCommand(_ =>
        {
            IsAddDriverFormVisible = !IsAddDriverFormVisible;
        });


        #endregion

        #region Методы
        private void LoadCities(string from = null, string to = null)
        {
            var routesList = _dbContext.Routes
                             .Include(r => r.Driver)
                             .ToList();
            Routes.Clear();
            foreach (var route in routesList)
            {
                Routes.Add(route);
            }

            if (!Routes.Any())
            {
                CitiesFrom = new ObservableCollection<string>();
                CitiesTo = new ObservableCollection<string>();
                return;
            }

            var allCities = Routes
                .SelectMany(r => new[] { r.FromCity, r.ToCity })
                .Where(c => !string.IsNullOrWhiteSpace(c))
                .Distinct()
                .OrderBy(c => c)
                .ToList();

            CitiesFrom = new ObservableCollection<string>(allCities);
            CitiesTo = new ObservableCollection<string>(allCities);

            SelectedCityFrom = from ?? CitiesFrom.FirstOrDefault();
            SelectedCityTo = to ?? CitiesTo.FirstOrDefault();
        }


        private void LoadTimeOptions()
        {
            TimeOptions = new ObservableCollection<string>
                {
                    "Любое",
                    "Утро",
                    "День",
                    "Вечер",
                    "Ночь"
                };

            SelectedTime = TimeOptions.FirstOrDefault();
        }

        private void SwapCities()
        {
            (SelectedCityFrom, SelectedCityTo) = (SelectedCityTo, SelectedCityFrom);
        }

        private async void SearchRoutee()
        {
            try
            {
                if (string.IsNullOrEmpty(SelectedCityFrom) || string.IsNullOrEmpty(SelectedCityTo))
                    throw new ArgumentException("Не выбрано место отправления или назначения");

                if (string.IsNullOrEmpty(SelectedTime))
                    throw new ArgumentException("Не выбрано время");

                var query = _dbContext.Routes
                            .Include(r => r.Driver)
                            .Where(r => r.FromCity == SelectedCityFrom && r.ToCity == SelectedCityTo && r.DepartureTime.Date == SelectedDate.Date);

                if (SelectedTime != "Любое" && !string.IsNullOrEmpty(SelectedTime))
                {
                    query = query.Where(r => r.Time == SelectedTime);
                }

                var routes = await query.OrderBy(r => r.DepartureTime).ToListAsync();

                Routes = new ObservableCollection<Route>(routes);

                if (!Routes.Any())
                {
                    NoRoutesMessage = "Маршруты не найдены";
                }
                else
                {
                    NoRoutesMessage = string.Empty;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске маршрутов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void NavigateToMainPage(object? parameter)
        {
            var page = new MainWindow();
            //WindowManagerService.ShowWindow(page);
            Application.Current.Windows.OfType<AdminPanelWindow>().FirstOrDefault()?.Close();
        }
        private void ToggleRoutesVisibility()
        {
            IsRoutesVisible = !IsRoutesVisible;
        }
        private void ToggleDriverPanelVisibility()
        {
            IsDriverPanelVisible = !IsDriverPanelVisible;
        }
        private void ShowAddRouteForm()
        {
            IsAddRouteFormVisible = true;
            NewRoute = new Route
            {
                DepartureTime = new DateTime(2025, 5, 21, 12, 0, 0)
            };
        }
        public static event Action<Route> RouteAdded;
        private async Task SaveNewRoute()
        {
            if (IsValidRoute(NewRoute))
            {
                try
                {
                    _dbContext.Routes.Add(NewRoute);
                    await _dbContext.SaveChangesAsync();

                    Routes.Add(NewRoute);

                    RouteAdded?.Invoke(NewRoute);
                    NewRoute.DriverId = SelectedDriverForRoute?.Id;

                    IsAddRouteFormVisible = false;
                    NewRoute = new Route();
                }
                catch (Exception ex)
                {
                    string errorMessage = $"Ошибка при добавлении маршрута: {ex.Message}";
                    if (ex.InnerException != null)
                    {
                        errorMessage += $"\nВнутреннее исключение: {ex.InnerException.Message}";
                    }
                    MessageBox.Show(errorMessage, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, заполните все поля корректно.");
            }
        }

        private bool CanSaveDriver()
        {
            return string.IsNullOrEmpty(Error);
        }
        private void CloseAddDriver()
        {
            IsAddDriverFormVisible = false;
        }
        private void SaveDriver(object? parameter)
        {
            if (!CanSaveDriver())
            {
                MessageBox.Show("Заполните все поля корректно.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                NewDriver.PasswordHash = BCrypt.Net.BCrypt.HashPassword(Password);

                using (var db = new AppDbContext())
                {
                    db.Drivers.Add(NewDriver);
                    db.SaveChanges();
                }

                MessageBox.Show("Водитель успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                NewDriver = new Driver();
                Password = string.Empty;
                OnPropertyChanged(nameof(NewDriver));
                OnPropertyChanged(nameof(Password));
                IsAddDriverFormVisible = false;
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"Ошибка при сохранении в базу данных: {dbEx.InnerException?.Message ?? dbEx.Message}",
                                "Ошибка БД", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}",
                                "Неизвестная ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        public string Error => null;

        public string this[string columnName]
        {
            get
            {
                string error = null;

                switch (columnName)
                {
                    case nameof(NewDriver.FirstName):
                        if (string.IsNullOrWhiteSpace(NewDriver.FirstName))
                            error = "Имя обязательно";
                        break;

                    case nameof(NewDriver.Surname):
                        if (string.IsNullOrWhiteSpace(NewDriver.Surname))
                            error = "Фамилия обязательна";
                        break;

                    case nameof(NewDriver.Phone):
                        if (string.IsNullOrWhiteSpace(NewDriver.Phone) || !Regex.IsMatch(NewDriver.Phone, @"^\+?\d{10,15}$"))
                            error = "Некорректный номер телефона";
                        break;

                    case nameof(NewDriver.Email):
                        if (string.IsNullOrWhiteSpace(NewDriver.Email) || !Regex.IsMatch(NewDriver.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                            error = "Некорректный email";
                        break;

                    case nameof(Password):
                        if (string.IsNullOrWhiteSpace(Password) || Password.Length < 6)
                            error = "Пароль должен быть не менее 6 символов";
                        break;
                }

                return error;
            }
        }
        private void CancelAddRoute()
        {
            IsAddRouteFormVisible = false;
            NewRoute = new Route();
        }

        private bool IsValidRoute(Route route)
        {
            bool isDepartureTimeValid = route.DepartureTime > DateTime.Now;
            bool isPriceValid = route.Price > 0;
            bool isSeatsAvailableValid = route.SeatsAvailable > 0;
            return isDepartureTimeValid && isPriceValid && isSeatsAvailableValid;
        }
        private async Task LoadRoutes()
        {
            try
            {
                var localRoutes = await _dbContext.Routes
                                       .Include(r => r.Driver)
                                       .OrderBy(r => r.DepartureTime)
                                       .ToListAsync();
                var problematicRouteInLocal = localRoutes.FirstOrDefault(r => r.Id == 2);
                if (problematicRouteInLocal != null)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadRoutes - Local: RouteId={problematicRouteInLocal.Id}, DriverId={problematicRouteInLocal.DriverId}, Driver is {(problematicRouteInLocal.Driver == null ? "NULL" : "NOT NULL")}");
                }
                this.Routes.Clear();
                foreach (var routeToAdd in localRoutes)
                {
                    if (routeToAdd.Id == 2)
                    {
                        System.Diagnostics.Debug.WriteLine($"LoadRoutes - Before Add to Observable: RouteId={routeToAdd.Id}, DriverId={routeToAdd.DriverId}, Driver is {(routeToAdd.Driver == null ? "NULL" : "NOT NULL")}");
                    }
                    this.Routes.Add(routeToAdd);
                }
                var problematicRouteInObservable = this.Routes.FirstOrDefault(r => r.Id == 2);
                if (problematicRouteInObservable != null)
                {
                    System.Diagnostics.Debug.WriteLine($"LoadRoutes - After Add to Observable: RouteId={problematicRouteInObservable.Id}, DriverId={problematicRouteInObservable.DriverId}, Driver is {(problematicRouteInObservable.Driver == null ? "NULL" : "NOT NULL")}");
                }
                foreach (var routeInCollection in this.Routes)
                {
                    if (routeInCollection.Id == 2)
                    {
                        System.Diagnostics.Debug.WriteLine($"LoadRoutes POST-FILL: RouteId={routeInCollection.Id}, RouteHashCode={routeInCollection.GetHashCode()}, DriverId={routeInCollection.DriverId}, Driver is {(routeInCollection.Driver == null ? "NULL" : "NOT NULL, HashCode=" + routeInCollection.Driver.GetHashCode())}");
                    }
                }
                NoRoutesMessage = this.Routes.Count == 0 ? "Маршруты не найдены" : string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке маршрутов: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Error in LoadRoutes: {ex.Message}");
            }
        }
        private async Task LoadDrivers()
        {

            using (var context = new AppDbContext())
            {
                var driversFromDb = context.Drivers.ToList();
                Console.WriteLine("Водителей в базе: " + driversFromDb.Count);
                Drivers.Clear();
                foreach (var driver in driversFromDb)
                {
                    Drivers.Add(driver);
                }
            }
        }

        private async Task LoadAndToggleRoutes()
        {
            if (!IsRoutesVisible)
                await LoadRoutes();

            IsRoutesVisible = !IsRoutesVisible;
        }
        private async Task LoadAndToggleDrivers()
        {
            if (!IsDriverPanelVisible)
                await LoadDrivers();

            IsDriverPanelVisible = !IsDriverPanelVisible;
        }
        private async Task SaveEditedRoute()
        {
            if (SelectedRoute == null) return;

            var result = MessageBox.Show("Сохранить изменения?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    var entity = await _dbContext.Routes.FindAsync(SelectedRoute.Id);
                    if (entity != null)
                    {
                        entity.DepartureTime = EditedDepartureTime;
                        entity.DriverId = SelectedDriverForRoute?.Id;

                        await _dbContext.SaveChangesAsync();
                        await LoadRoutes();

                        SelectedRoute = null;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
                }
            }
        }

        private async Task DeleteRoute()
        {
            if (SelectedRoute == null) return;

            var result = MessageBox.Show("Вы уверены, что хотите удалить этот маршрут?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    var routeToDelete = await _dbContext.Routes.FindAsync(SelectedRoute.Id);
                    if (routeToDelete != null)
                    {
                        _dbContext.Routes.Remove(routeToDelete);
                        await _dbContext.SaveChangesAsync();

                        await LoadRoutes();
                        SelectedRoute = null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении маршрута: {ex.Message}");
                }
            }
        }
        private async Task SaveEditedDriver()
        {
            if (SelectedDriver == null) return;

            var result = MessageBox.Show("Сохранить изменения?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    var driverInDb = await _dbContext.Drivers.FindAsync(SelectedDriver.Id);
                    if (driverInDb != null)
                    {
                        driverInDb.Surname = SelectedDriver.Surname;
                        driverInDb.FirstName = SelectedDriver.FirstName;
                        driverInDb.LastName = SelectedDriver.LastName;
                        driverInDb.Phone = SelectedDriver.Phone;
                        driverInDb.Category = SelectedDriver.Category;
                        driverInDb.Email = SelectedDriver.Email;
                        driverInDb.PasswordHash = SelectedDriver.PasswordHash;

                        await _dbContext.SaveChangesAsync();
                        await LoadDrivers();
                        SelectedDriver = null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
                }
            }
        }


        private async Task DeleteDriver()
        {
            if (SelectedDriver == null) return;

            var result = MessageBox.Show("Удалить водителя?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    var entity = await _dbContext.Drivers.FindAsync(SelectedDriver.Id);
                    if (entity != null)
                    {
                        _dbContext.Drivers.Remove(entity);
                        await _dbContext.SaveChangesAsync();
                        await LoadDrivers();
                        SelectedDriver = null;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}");
                }
            }
        }
        #endregion

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        #endregion
    }
}
