﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp3.Data;
using WpfApp3.Services;
using WpfApp3.Views;


namespace WpfApp3.ViewModel
{
    public class DriverPanelWindow_MVVM : INotifyPropertyChanged
    {
        private string _driverFullName;
        public string DriverFullName
        {
            get => _driverFullName;
            private set { _driverFullName = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Route> _assignedRoutes;
        public ObservableCollection<Route> AssignedRoutes
        {
            get => _assignedRoutes;
            private set { _assignedRoutes = value; OnPropertyChanged(); }
        }

        private Route _selectedRoute;
        public Route SelectedRoute
        {
            get => _selectedRoute;
            set
            {
                if (_selectedRoute != value)
                {
                    _selectedRoute = value;
                    OnPropertyChanged();
                    LoadPassengersAndTicketsForSelectedRouteAsync();
                }
            }
        }
        private ObservableCollection<TicketPurchase> _ticketPurchasesForSelectedRoute;
        public ObservableCollection<TicketPurchase> TicketPurchasesForSelectedRoute
        {
            get => _ticketPurchasesForSelectedRoute;
            private set { _ticketPurchasesForSelectedRoute = value; OnPropertyChanged(); }
        }

        private bool _isLoadingData;
        public bool IsLoadingData
        {
            get => _isLoadingData;
            private set { _isLoadingData = value; OnPropertyChanged(); }
        }

        public ICommand CancelTripCommand { get; private set; }
        public ICommand NavigateToMainPageCommand { get; }

        public DriverPanelWindow_MVVM()
        {
            AssignedRoutes = new ObservableCollection<Route>();
            TicketPurchasesForSelectedRoute = new ObservableCollection<TicketPurchase>();
            NavigateToMainPageCommand = new RelayCommand(OpenMain);

            CancelTripCommand = new RelayCommand(
                async param => await ExecuteCancelTripAsync(param as TicketPurchase),
                () => SelectedRoute != null && !IsLoadingData

            );

            _ = LoadInitialDataAsync();
        }

        private void OpenMain(object? parameter)
        {
            var page = new MainWindow();
            WindowManagerService.ShowWindow(page);
            Application.Current.Windows.OfType<DriverPanelWindow>().FirstOrDefault()?.Close();
        }
        private async Task LoadInitialDataAsync()
        {
            if (!UserSession.IsDriver || UserSession.CurrentDriver == null)
            {
                MessageBox.Show("Критическая ошибка: Сессия водителя недействительна. Пожалуйста, войдите снова.", "Ошибка сессии", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var currentDriverFromSession = UserSession.CurrentDriver;
            DriverFullName = $"{currentDriverFromSession.Surname} {currentDriverFromSession.FirstName} {currentDriverFromSession.LastName}";

            await LoadAssignedRoutesAsync(currentDriverFromSession.Id);
        }

        private async Task LoadAssignedRoutesAsync(int driverId)
        {
            IsLoadingData = true;
            try
            {
                using (var dbContext = new AppDbContext())
                {
                    var routesForDriver = await dbContext.Routes
                                                .Where(r => r.DriverId == driverId)
                                                .OrderBy(r => r.ExactDepartureTime)
                                                .ToListAsync();
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        AssignedRoutes.Clear();
                        foreach (var route in routesForDriver)
                        {
                            AssignedRoutes.Add(route);
                        }
                        if (SelectedRoute != null && !AssignedRoutes.Any(r => r.Id == SelectedRoute.Id))
                        {
                            SelectedRoute = null;
                        }
                        else if (SelectedRoute != null)
                        {
                            SelectedRoute = AssignedRoutes.FirstOrDefault(r => r.Id == SelectedRoute.Id);
                        }

                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке маршрутов: {ex.Message}", "Ошибка данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsLoadingData = false;
            }
        }
        private async Task LoadPassengersAndTicketsForSelectedRouteAsync()
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                TicketPurchasesForSelectedRoute.Clear();
            });

            if (SelectedRoute == null)
            {
                return;
            }

            IsLoadingData = true;

            try
            {
                using (var dbContext = new AppDbContext())
                {
                    var purchases = await dbContext.TicketPurchases
                                          .Where(tp => tp.RouteId == SelectedRoute.Id)
                                          .Include(tp => tp.User)
                                          .OrderBy(tp => tp.User.LastName)
                                          .ThenBy(tp => tp.User.FirstName)
                                          .ToListAsync();
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        foreach (var purchase in purchases)
                        {
                            TicketPurchasesForSelectedRoute.Add(purchase);
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке пассажиров для маршрута ID {SelectedRoute.Id}: {ex.Message}", "Ошибка данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsLoadingData = false;
            }
        }

        private async Task ExecuteCancelTripAsync(TicketPurchase purchaseToCancel)
        {
            if (purchaseToCancel == null || SelectedRoute == null) return;

            string passengerName = "Неизвестный пассажир";
            if (purchaseToCancel.User != null) 
            {
                passengerName = $"{purchaseToCancel.User.LastName} {purchaseToCancel.User.FirstName}";
            }

            var result = MessageBox.Show($"Вы уверены, что хотите отменить поездку для пассажира {passengerName} (Билет ID: {purchaseToCancel.Id}) на маршрут {SelectedRoute.FromCity} - {SelectedRoute.ToCity}?",
                                         "Подтверждение отмены", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                IsLoadingData = true;
                CommandManager.InvalidateRequerySuggested();

                try
                {
                    bool success = false;
                    using (var dbContext = new AppDbContext())
                    {
                        var trackedPurchase = await dbContext.TicketPurchases.FindAsync(purchaseToCancel.Id);
                        if (trackedPurchase != null)
                        {
                            dbContext.TicketPurchases.Remove(trackedPurchase);

                            var route = await dbContext.Routes.FindAsync(SelectedRoute.Id);
                            if (route != null)
                            {
                                route.SeatsAvailable++;
                            }

                            await dbContext.SaveChangesAsync();
                            success = true;
                        }
                        else
                        {
                            MessageBox.Show("Не удалось найти билет для отмены в базе данных. Возможно, он уже был отменен.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }

                    if (success)
                    {
                        await LoadPassengersAndTicketsForSelectedRouteAsync();
                        if (UserSession.CurrentDriver != null)
                        {
                            await LoadAssignedRoutesAsync(UserSession.CurrentDriver.Id);
                        }

                        MessageBox.Show("Поездка успешно отменена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    MessageBox.Show($"Произошла ошибка параллелизма при отмене билета. Возможно, данные были изменены другим пользователем. Пожалуйста, обновите список и попробуйте снова.\nДетали: {ex.Message}", "Ошибка параллелизма", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при отмене поездки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    IsLoadingData = false;
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}