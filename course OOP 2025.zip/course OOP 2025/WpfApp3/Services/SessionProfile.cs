﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3.Data;

namespace WpfApp3.Services
{
    class SessionProfile
    {
        private static User _currentUser;
        private static Driver _currentDriver;
        public static bool IsUserLoggedIn => _currentUser != null;
        public static bool IsDriverLoggedIn => _currentDriver != null;
        public enum LoggedInEntityType { None, User, Driver }
        public static LoggedInEntityType CurrentEntityType
        {
            get
            {
                if (IsUserLoggedIn) return LoggedInEntityType.User;
                if (IsDriverLoggedIn) return LoggedInEntityType.Driver;
                return LoggedInEntityType.None;
            }
        }
        public static int? CurrentUserId => _currentUser?.Id;
        public static string CurrentUserEmail => _currentUser?.Email;
        public static string CurrentUserPasswordHash => _currentUser?.PasswordHash;

        public static int? CurrentDriverId => _currentDriver?.Id;
        public static string CurrentDriverEmail => _currentDriver?.Email;
        public static string CurrentDriverPasswordHash => _currentDriver?.PasswordHash;

        public static void LoginAsUser(User user)
        {
            _currentUser = user;
            _currentDriver = null;
        }

        public static void LoginAsDriver(Driver driver)
        {
            _currentDriver = driver;
            _currentUser = null;
        }

        public static void Logout()
        {
            _currentUser = null;
            _currentDriver = null;
        }
        public static void UpdateUserEmail(string newEmail)
        {
            if (_currentUser != null)
            {
                _currentUser.Email = newEmail;
            }
        }

        public static void UpdateUserPasswordHash(string newPasswordHash)
        {
            if (_currentUser != null)
            {
                _currentUser.PasswordHash = newPasswordHash;
            }
        }
    }
}