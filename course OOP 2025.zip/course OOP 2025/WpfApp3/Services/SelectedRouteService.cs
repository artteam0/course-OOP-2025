﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3.Data;

namespace WpfApp3.Services
{
    public static class SelectedRouteService
    {
        public static List<Route> SelectedRoutes { get; } = new List<Route>();

        public static void AddRoute(Route route)
        {
            if (route != null && !SelectedRoutes.Contains(route))
            {
                SelectedRoutes.Add(route);
            }
        }
        public static void ClearRoutes()
        {
            SelectedRoutes.Clear();
        }
        public static void RemoveRoute(Route route)
        {
            if (SelectedRoutes.Contains(route))
                SelectedRoutes.Remove(route);
        }
    }
}
