﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3.Data;

namespace WpfApp3.Services
{
    public static class SessionService
    {
        public static User CurrentUser { get; set; } = null;

        public static bool IsLoggedIn => CurrentUser != null;
    }
}
