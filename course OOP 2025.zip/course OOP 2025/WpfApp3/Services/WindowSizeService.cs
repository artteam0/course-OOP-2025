﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp3.Services
{
    public class WindowSizeService
    {
        public double Width { get; set; } = 1000;
        public double Height { get; set; } = 600;
        public WindowState State { get; set; } = WindowState.Normal;
        public double Left { get; set; } = 0;
        public double Top { get; set; } = 0;
    }

}
