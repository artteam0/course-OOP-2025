﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3.Data;

namespace WpfApp3.Services
{
    class AuthenticationService
    {
        private static User _currentUser;

        public static bool IsUserLoggedIn => _currentUser != null;

        public static int? CurrentUserId => _currentUser?.Id;
        public static string CurrentUserEmail => _currentUser?.Email;
        public static void Login(User user)
        {
            _currentUser = user;
        }
        public static void Logout()
        {
            _currentUser = null;
        }
        public static User GetCurrentUser()
        {
            return _currentUser;
        }
    }
}
