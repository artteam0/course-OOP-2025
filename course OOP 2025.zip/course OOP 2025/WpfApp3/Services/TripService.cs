﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp3.Data;

namespace WpfApp3.Services
{
    public static class TripService
    {
        public static List<Route> Trips { get; } = new List<Route>();

        public static void AddTrip(Route route)
        {
            if (route != null && !Trips.Contains(route))
            {
                Trips.Add(route);
            }
        }

        public static void ClearTrips()
        {
            Trips.Clear();
        }
    }
}
