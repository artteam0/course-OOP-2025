﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows;

//namespace WpfApp3.Services
//{
//    public static class WindowManagerService
//    {
//        public static void ShowWindow(Window window)
//        {
//            var settings = App.WindowSizeService;

//            window.Width = settings.Width;
//            window.Height = settings.Height;
//            window.WindowState = settings.State;
//            window.Left = settings.Left;
//            window.Top = settings.Top;
//            window.WindowStartupLocation = WindowStartupLocation.Manual;

//            window.SizeChanged += OnWindowSizeChanged;
//            window.LocationChanged += OnWindowLocationChanged;
//            window.StateChanged += OnWindowStateChanged;

//            window.Show();
//        }

//        private static void OnWindowSizeChanged(object sender, SizeChangedEventArgs e)
//        {
//            if (sender is Window window && window.WindowState == WindowState.Normal)
//            {
//                var settings = App.WindowSizeService;
//                settings.Width = window.ActualWidth;
//                settings.Height = window.ActualHeight;
//            }
//        }

//        private static void OnWindowLocationChanged(object sender, EventArgs e)
//        {
//            if (sender is Window window && window.WindowState == WindowState.Normal)
//            {
//                var settings = App.WindowSizeService;
//                settings.Left = window.Left;
//                settings.Top = window.Top;
//            }
//        }

//        private static void OnWindowStateChanged(object sender, EventArgs e)
//        {
//            if (sender is Window window)
//            {
//                App.WindowSizeService.State = window.WindowState;
//            }
//        }
//    }
//}
