﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
// using WpfApp3.Services; // WindowSizeService - keep if used elsewhere, not critical for lang/theme

// Ensure correct namespace for Settings
// using WpfApp3.Properties; // If not global

namespace WpfApp3
{
    public partial class App : Application
    {
        // WindowSizeService - keep if you use it
        // public static WindowSizeService WindowSizeService { get; } = new WindowSizeService();

        // --- Языковые настройки ---
        private static List<CultureInfo> m_AppLanguages = new List<CultureInfo>();
        private const string LanguageFilePrefix = "Resources/Dictionary_"; // Path to language dictionaries
        private static ResourceDictionary _currentLoadedLanguageDictionary = null;

        public static List<CultureInfo> AvailableLanguages => m_AppLanguages; // Used by Profile.xaml.cs as App.Languages
        public static event EventHandler CurrentLanguageChanged; // Used by Profile.xaml.cs as App.LanguageChanged

        // --- Тематические настройки (Temporarily Disabled) ---
        // public enum AppThemeOptions { Light, Dark }
        // private static AppThemeOptions _currentAppThemeSetting;
        // private static ResourceDictionary _currentLoadedThemeDictionary = null;
        // private const string ThemeFilePrefix = "Themes/"; 
        // public static event EventHandler CurrentThemeChanged;

        public App()
        {
            InitializeComponent();

            // Initialize list of available languages
            m_AppLanguages.Clear();
            m_AppLanguages.Add(new CultureInfo("en-US")); // English
            m_AppLanguages.Add(new CultureInfo("ru-RU")); // Russian

            // Set default language on application startup
            string savedLangName = WpfApp3.Properties.Settings.Default.DefaultLanguage;
            SetInitialApplicationLanguage(savedLangName);

            // --- Theme initialization (Temporarily Disabled) ---
            // string savedThemeName = WpfApp3.Properties.Settings.Default.DefaultTheme;
            // AppThemeOptions initialTheme = AppThemeOptions.Light; 
            // if (!string.IsNullOrEmpty(savedThemeName) && Enum.TryParse(savedThemeName, true, out AppThemeOptions parsedTheme))
            // {
            // initialTheme = parsedTheme;
            // }
            // CurrentApplicationTheme = initialTheme;
        }

        // This is the property Profile.xaml.cs refers to as App.Language
        public static CultureInfo Language
        {
            get => CurrentApplicationLanguage;
            set => CurrentApplicationLanguage = value;
        }

        public static CultureInfo CurrentApplicationLanguage
        {
            get { return System.Threading.Thread.CurrentThread.CurrentUICulture; }
            set
            {
                if (value == null) throw new ArgumentNullException(nameof(value));

                // Avoid reloading if the language is the same and a dictionary is already successfully loaded
                if (value.Equals(System.Threading.Thread.CurrentThread.CurrentUICulture) &&
                    _currentLoadedLanguageDictionary != null &&
                    _currentLoadedLanguageDictionary.Source != null)
                {
                    return;
                }

                System.Threading.Thread.CurrentThread.CurrentUICulture = value;

                ResourceDictionary newLangDict = new ResourceDictionary();
                string cultureSuffix;
                switch (value.Name)
                {
                    case "ru-RU": cultureSuffix = "RU"; break;
                    case "en-US": cultureSuffix = "EN"; break;
                    default: cultureSuffix = "EN"; break; // Fallback to English for unknown cultures
                }
                string dictionaryPath = $"{LanguageFilePrefix}{cultureSuffix}.xaml";

                bool dictionaryLoaded = false;
                try
                {
                    newLangDict.Source = new Uri(dictionaryPath, UriKind.Relative);
                    dictionaryLoaded = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading language dictionary: {dictionaryPath}\n{ex.Message}", "Language Loading Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    // Attempt to load fallback (English) if the primary failed and wasn't English
                    if (cultureSuffix != "EN")
                    {
                        try
                        {
                            string fallbackPath = $"{LanguageFilePrefix}EN.xaml";
                            newLangDict.Source = new Uri(fallbackPath, UriKind.Relative);
                            dictionaryLoaded = true; // Fallback loaded
                            MessageBox.Show($"Successfully loaded fallback English dictionary: {fallbackPath}", "Fallback Loaded", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        catch (Exception exFallback)
                        {
                            MessageBox.Show($"Error loading fallback English language dictionary: {LanguageFilePrefix}EN.xaml\n{exFallback.Message}", "Language Loading Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            // Both primary and fallback failed. newLangDict.Source will be null.
                        }
                    }
                }

                // Remove the old language dictionary from MergedDictionaries if it exists
                if (_currentLoadedLanguageDictionary != null)
                {
                    Application.Current.Resources.MergedDictionaries.Remove(_currentLoadedLanguageDictionary);
                }

                if (dictionaryLoaded && newLangDict.Source != null)
                {
                    Application.Current.Resources.MergedDictionaries.Add(newLangDict);
                    _currentLoadedLanguageDictionary = newLangDict; // Update the reference to the currently loaded dictionary
                }
                else
                {
                    _currentLoadedLanguageDictionary = null; // No dictionary is active
                    MessageBox.Show("No language dictionary could be loaded. UI text might not be localized.", "Localization Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                WpfApp3.Properties.Settings.Default.DefaultLanguage = value.Name;
                WpfApp3.Properties.Settings.Default.Save();

                CurrentLanguageChanged?.Invoke(Application.Current, EventArgs.Empty);
            }
        }

        private static void SetInitialApplicationLanguage(string cultureName)
        {
            CultureInfo targetCulture;

            if (string.IsNullOrEmpty(cultureName))
            {
                // Try to use system's current UI culture if supported, else default to English or first available
                targetCulture = m_AppLanguages.FirstOrDefault(lang => lang.Equals(CultureInfo.CurrentUICulture))
                                ?? m_AppLanguages.FirstOrDefault(lang => lang.Name == "en-US") // Preferred default
                                ?? m_AppLanguages.FirstOrDefault(); // First in list as absolute fallback
            }
            else
            {
                try
                {
                    targetCulture = new CultureInfo(cultureName);
                    // Ensure the saved culture is one we actually support
                    if (!m_AppLanguages.Any(lang => lang.Equals(targetCulture)))
                    {
                        // Saved language not supported, fallback
                        targetCulture = m_AppLanguages.FirstOrDefault(lang => lang.Name == "en-US")
                                        ?? m_AppLanguages.FirstOrDefault();
                    }
                }
                catch (CultureNotFoundException)
                {
                    // Saved culture name is invalid, fallback
                    targetCulture = m_AppLanguages.FirstOrDefault(lang => lang.Name == "en-US")
                                    ?? m_AppLanguages.FirstOrDefault();
                }
            }

            // Absolute fallback if no culture could be determined (e.g., m_AppLanguages is empty)
            if (targetCulture == null)
            {
                targetCulture = new CultureInfo("en-US");
                MessageBox.Show("No target culture determined, defaulting to en-US.", "Language Init Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            // Set language through the property to trigger dictionary loading
            CurrentApplicationLanguage = targetCulture;
        }

        // --- Theme Property (Temporarily Disabled) ---
        // public static AppThemeOptions CurrentApplicationTheme
        // {
        //     get { return _currentAppThemeSetting; }
        //     set
        //     {
        //         // ... (Theme logic was here) ...
        //         // For now, this does nothing or can be removed entirely
        //     }
        // }
    }
}